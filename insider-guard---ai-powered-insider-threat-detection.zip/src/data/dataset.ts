import { UserActivityRecord, SecurityAlert, PredictionHistoryEntry } from '../types';

// Deterministic Pseudo-Random Generator for consistent dataset reproduction
function seededRandom(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

const departments = ['Engineering', 'Finance', 'IT', 'Sales', 'Human Resources'] as const;
const rolesByDept: Record<string, string[]> = {
  Engineering: ['Senior Software Engineer', 'DevOps Specialist', 'QA Engineer', 'Tech Lead', 'Cloud Architect'],
  Finance: ['Financial Analyst', 'Senior Controller', 'Accounts Auditor', 'Payroll Specialist'],
  IT: ['Systems Administrator', 'Network Engineer', 'Helpdesk Specialist', 'Security Operator'],
  Sales: ['Account Executive', 'Enterprise Sales Director', 'Customer Success Lead'],
  'Human Resources': ['HR Generalist', 'Recruitment Specialist', 'HR Director']
};

export function generateInsiderActivityDataset(): UserActivityRecord[] {
  const records: UserActivityRecord[] = [];
  const rand = seededRandom(42);

  // Exact target statistics: 1250 total, 1180 normal, 70 threats (with 23 high risk)
  const total = 1250;
  const targetThreats = 70;
  const targetHighRisk = 23;

  // Let's explicitly define known highlighted user IDs from the requirements:
  // User U003: Abnormal, High file access, High email, Risk High (87.4%)
  // User U002: Normal login, High file access, Normal email, Risk Med
  // User U001: Normal login, Normal file access, Normal email, Risk Low
  // User U021: Abnormal file access, Risk Med (64-71%)
  // User U017: Previous suspicious, resolved (12%)
  // User_1042: Suspicious Activity
  // User_0831: Unusual File Access
  // User_0291: Abnormal Login Pattern

  // Pre-generate which indices will be threats
  const threatIndices = new Set<number>();
  // Pick designated indices
  const designatedThreats = [3, 21, 42, 67, 89, 104, 131, 156, 189, 204, 231, 260, 291, 312, 345, 381, 410, 442, 478, 510, 542, 578, 610];
  designatedThreats.forEach(i => threatIndices.add(i));
  while (threatIndices.size < targetThreats) {
    const candidate = Math.floor(rand() * total);
    if (candidate !== 1 && candidate !== 2 && candidate !== 17) {
      threatIndices.add(candidate);
    }
  }

  // Pre-select high risk subset of threats (23 total)
  const highRiskIndices = new Set<number>();
  designatedThreats.slice(0, 18).forEach(i => highRiskIndices.add(i));
  const threatArr = Array.from(threatIndices);
  let idxCounter = 0;
  while (highRiskIndices.size < targetHighRisk && idxCounter < threatArr.length) {
    highRiskIndices.add(threatArr[idxCounter++]);
  }

  const baseDate = new Date(2026, 8, 28, 14, 0, 0); // 28 Sep 2026

  for (let i = 1; i <= total; i++) {
    const isThreat = threatIndices.has(i);
    const isHighRisk = highRiskIndices.has(i);
    const dept = departments[Math.floor(rand() * departments.length)];
    const roleList = rolesByDept[dept];
    const role = roleList[Math.floor(rand() * roleList.length)];
    
    // User ID formatting
    let userId = `U${String(i).padStart(3, '0')}`;
    if (i === 1042) userId = 'User_1042';
    if (i === 831) userId = 'User_0831';
    if (i === 291) userId = 'User_0291';
    if (i === 3) userId = 'U003';
    if (i === 2) userId = 'U002';
    if (i === 1) userId = 'U001';
    if (i === 21) userId = 'U021';
    if (i === 17) userId = 'U017';

    // Timestamp within last 7 days
    const timeOffsetDays = (i % 7);
    const timeOffsetHours = Math.floor(rand() * 24);
    const timeOffsetMins = Math.floor(rand() * 60);
    const recordDate = new Date(baseDate.getTime() - (timeOffsetDays * 86400000 + timeOffsetHours * 3600000 + timeOffsetMins * 60000));

    let loginFreq: number;
    let fileAccess: number;
    let sensFiles: number;
    let emailAct: number;
    let extRecipients: number;
    let usb: boolean;
    let afterHours: boolean;
    let failedLogins: number;
    let dataMB: number;
    let threatScore: number;
    let riskLevel: 'Low' | 'Medium' | 'High';
    let threatCategory: 'None' | 'Data Exfiltration' | 'Privilege Escalation' | 'Unauthorized Access' | 'Intellectual Property Theft' = 'None';

    if (userId === 'U003') {
      // Special profile for U003
      loginFreq = 8;
      fileAccess = 42;
      sensFiles = 18;
      emailAct = 17;
      extRecipients = 14;
      usb = true;
      afterHours = true;
      failedLogins = 4;
      dataMB = 4850;
      threatScore = 0.874;
      riskLevel = 'High';
      threatCategory = 'Data Exfiltration';
    } else if (userId === 'U002') {
      loginFreq = 5;
      fileAccess = 28;
      sensFiles = 4;
      emailAct = 12;
      extRecipients = 3;
      usb = false;
      afterHours = false;
      failedLogins = 1;
      dataMB = 620;
      threatScore = 0.52;
      riskLevel = 'Medium';
      threatCategory = 'Unauthorized Access';
    } else if (userId === 'U001') {
      loginFreq = 4;
      fileAccess = 14;
      sensFiles = 0;
      emailAct = 9;
      extRecipients = 1;
      usb = false;
      afterHours = false;
      failedLogins = 0;
      dataMB = 120;
      threatScore = 0.08;
      riskLevel = 'Low';
      threatCategory = 'None';
    } else if (userId === 'U021') {
      loginFreq = 7;
      fileAccess = 38;
      sensFiles = 9;
      emailAct = 15;
      extRecipients = 8;
      usb = true;
      afterHours = false;
      failedLogins = 2;
      dataMB = 1890;
      threatScore = 0.64;
      riskLevel = 'Medium';
      threatCategory = 'Data Exfiltration';
    } else if (userId === 'U017') {
      loginFreq = 5;
      fileAccess = 16;
      sensFiles = 1;
      emailAct = 11;
      extRecipients = 0;
      usb = false;
      afterHours = false;
      failedLogins = 0;
      dataMB = 190;
      threatScore = 0.12;
      riskLevel = 'Low';
      threatCategory = 'None';
    } else if (isThreat) {
      if (isHighRisk) {
        loginFreq = Math.floor(7 + rand() * 12);
        fileAccess = Math.floor(35 + rand() * 45);
        sensFiles = Math.floor(12 + rand() * 25);
        emailAct = Math.floor(25 + rand() * 50);
        extRecipients = Math.floor(12 + rand() * 30);
        usb = rand() > 0.15;
        afterHours = rand() > 0.1;
        failedLogins = Math.floor(3 + rand() * 8);
        dataMB = Math.floor(2500 + rand() * 8000);
        threatScore = Number((0.80 + rand() * 0.18).toFixed(3));
        riskLevel = 'High';
        const cats = ['Data Exfiltration', 'Privilege Escalation', 'Intellectual Property Theft'] as const;
        threatCategory = cats[Math.floor(rand() * cats.length)];
      } else {
        loginFreq = Math.floor(5 + rand() * 8);
        fileAccess = Math.floor(24 + rand() * 25);
        sensFiles = Math.floor(4 + rand() * 10);
        emailAct = Math.floor(16 + rand() * 25);
        extRecipients = Math.floor(5 + rand() * 12);
        usb = rand() > 0.45;
        afterHours = rand() > 0.4;
        failedLogins = Math.floor(1 + rand() * 4);
        dataMB = Math.floor(900 + rand() * 2200);
        threatScore = Number((0.55 + rand() * 0.22).toFixed(3));
        riskLevel = 'Medium';
        const cats = ['Unauthorized Access', 'Data Exfiltration', 'Privilege Escalation'] as const;
        threatCategory = cats[Math.floor(rand() * cats.length)];
      }
    } else {
      // Normal behavior
      loginFreq = Math.floor(3 + rand() * 5);
      fileAccess = Math.floor(6 + rand() * 16);
      sensFiles = rand() > 0.8 ? 1 : 0;
      emailAct = Math.floor(4 + rand() * 14);
      extRecipients = Math.floor(rand() * 4);
      usb = rand() > 0.94;
      afterHours = rand() > 0.88;
      failedLogins = rand() > 0.85 ? 1 : 0;
      dataMB = Math.floor(40 + rand() * 280);
      threatScore = Number((0.02 + rand() * 0.22).toFixed(3));
      riskLevel = threatScore > 0.18 ? 'Medium' : 'Low';
      threatCategory = 'None';
    }

    records.push({
      id: `ACT-${String(i).padStart(5, '0')}`,
      userId,
      timestamp: recordDate.toISOString(),
      role,
      department: dept,
      loginFrequency: loginFreq,
      fileAccessCount: fileAccess,
      sensitiveFilesAccessed: sensFiles,
      emailActivity: emailAct,
      externalRecipients: extRecipients,
      usbUsage: usb,
      afterHoursActivity: afterHours,
      failedLogins,
      dataTransferMB: dataMB,
      threatScore,
      threatLabel: isThreat ? 'Threat' : 'Normal',
      riskLevel,
      threatCategory,
      investigationStatus: userId === 'U017' ? 'Resolved' : (isThreat ? 'Investigating' : 'Unreviewed')
    });
  }

  return records;
}

export const initialDataset = generateInsiderActivityDataset();

export function generateDatasetCsv(records: UserActivityRecord[] = initialDataset): string {
  const headers = [
    'user_id',
    'timestamp',
    'department',
    'role',
    'login_frequency',
    'file_access_count',
    'sensitive_files_accessed',
    'email_activity',
    'external_recipients',
    'usb_usage',
    'after_hours_activity',
    'failed_logins',
    'data_transfer_mb',
    'threat_score',
    'risk_level',
    'threat_category',
    'threat_label'
  ];

  const rows = records.map(r => [
    r.userId,
    r.timestamp,
    `"${r.department}"`,
    `"${r.role}"`,
    r.loginFrequency,
    r.fileAccessCount,
    r.sensitiveFilesAccessed,
    r.emailActivity,
    r.externalRecipients,
    r.usbUsage ? 1 : 0,
    r.afterHoursActivity ? 1 : 0,
    r.failedLogins,
    r.dataTransferMB,
    r.threatScore,
    r.riskLevel,
    `"${r.threatCategory}"`,
    r.threatLabel
  ].join(','));

  return [headers.join(','), ...rows].join('\n');
}

export const initialAlerts: SecurityAlert[] = [
  {
    id: 'ALT-1042',
    userId: 'User_1042',
    title: 'Suspicious Activity & Massive Data Staging',
    description: 'Multiple mass archive downloads outside working hours followed by external dispatch attempt.',
    riskLevel: 'High',
    riskProbability: 92,
    threatCategory: 'Data Exfiltration',
    timestamp: '14 mins ago',
    status: 'Active',
    keyAnomalies: ['48 Sensitive Files Accessed', 'After-Hours: 23:40 UTC', '4.2 GB Archive Staged', 'USB Device Mounted']
  },
  {
    id: 'ALT-0003',
    userId: 'U003',
    title: 'Unusual File Access & Multi-Factor Anomalies',
    description: 'Elevated file access count (42 documents) combined with USB peripheral and abnormal after-hours session.',
    riskLevel: 'High',
    riskProbability: 87,
    threatCategory: 'Data Exfiltration',
    timestamp: '42 mins ago',
    status: 'Active',
    keyAnomalies: ['File Access: 42 docs (320% of baseline)', 'USB Usage: Confirmed', 'After-hours Activity: Yes', 'Failed Logins: 4']
  },
  {
    id: 'ALT-0831',
    userId: 'User_0831',
    title: 'Unusual File Access Pattern in R&D Directory',
    description: 'System engineer accessing proprietary source code repositories outside standard project allocation.',
    riskLevel: 'Medium',
    riskProbability: 68,
    threatCategory: 'Unauthorized Access',
    timestamp: '2 hours ago',
    status: 'Active',
    keyAnomalies: ['Access to R&D root repositories', '31 File read requests in 10 minutes', 'Failed sudo attempt']
  },
  {
    id: 'ALT-0021',
    userId: 'U021',
    title: 'Abnormal File Access & External Recipient Spike',
    description: 'Spike in file downloads followed by outbound communication to unverified external domains.',
    riskLevel: 'Medium',
    riskProbability: 64,
    threatCategory: 'Data Exfiltration',
    timestamp: '4 hours ago',
    status: 'Active',
    keyAnomalies: ['File Access: 38 files', 'External Recipients: 8 unique domains', 'USB Storage Attached']
  },
  {
    id: 'ALT-0291',
    userId: 'User_0291',
    title: 'Abnormal Login Pattern & Rapid Geolocation Jitter',
    description: 'Concurrent authentication requests detected from distinct subnets with high session frequency.',
    riskLevel: 'Low',
    riskProbability: 38,
    threatCategory: 'Privilege Escalation',
    timestamp: '5 hours ago',
    status: 'Active',
    keyAnomalies: ['7 Login events within 30 minutes', 'VPN gateway hopping', 'Single authentication failure']
  },
  {
    id: 'ALT-0017',
    userId: 'U017',
    title: 'Previous Suspicious Activity (Audit Completed)',
    description: 'Prior anomalous file transfer verified as authorized batch database backup by IT manager.',
    riskLevel: 'Low',
    riskProbability: 12,
    threatCategory: 'None',
    timestamp: '1 day ago',
    status: 'Resolved',
    keyAnomalies: ['Authorized IT database maintenance script confirmed with ticket IT-8841']
  }
];

export const initialPredictionHistory: PredictionHistoryEntry[] = [
  {
    id: 'PRED-991',
    date: '28 Sep',
    time: '14:12',
    userId: 'U003',
    prediction: 'Threat',
    probability: 87,
    riskLevel: 'High',
    model: 'Random Forest + Elastic Net',
    status: 'Active',
    activitySnapshot: { logins: 8, files: 42, emails: 17, usb: true, afterHours: true }
  },
  {
    id: 'PRED-990',
    date: '28 Sep',
    time: '13:45',
    userId: 'U017',
    prediction: 'Normal',
    probability: 12,
    riskLevel: 'Low',
    model: 'Random Forest + Elastic Net',
    status: 'Resolved',
    activitySnapshot: { logins: 5, files: 16, emails: 11, usb: false, afterHours: false }
  },
  {
    id: 'PRED-989',
    date: '27 Sep',
    time: '19:20',
    userId: 'U021',
    prediction: 'Threat',
    probability: 71,
    riskLevel: 'Medium',
    model: 'Random Forest + Elastic Net',
    status: 'Investigating',
    activitySnapshot: { logins: 7, files: 38, emails: 15, usb: true, afterHours: false }
  },
  {
    id: 'PRED-988',
    date: '27 Sep',
    time: '16:05',
    userId: 'User_1042',
    prediction: 'Threat',
    probability: 92,
    riskLevel: 'High',
    model: 'Random Forest + Elastic Net',
    status: 'Active',
    activitySnapshot: { logins: 11, files: 58, emails: 34, usb: true, afterHours: true }
  },
  {
    id: 'PRED-987',
    date: '27 Sep',
    time: '11:15',
    userId: 'U001',
    prediction: 'Normal',
    probability: 8,
    riskLevel: 'Low',
    model: 'Random Forest + Elastic Net',
    status: 'Resolved',
    activitySnapshot: { logins: 4, files: 14, emails: 9, usb: false, afterHours: false }
  },
  {
    id: 'PRED-986',
    date: '26 Sep',
    time: '21:30',
    userId: 'User_0831',
    prediction: 'Threat',
    probability: 68,
    riskLevel: 'Medium',
    model: 'Random Forest + Elastic Net',
    status: 'Investigating',
    activitySnapshot: { logins: 6, files: 31, emails: 14, usb: false, afterHours: true }
  },
  {
    id: 'PRED-985',
    date: '26 Sep',
    time: '15:10',
    userId: 'User_0291',
    prediction: 'Normal',
    probability: 38,
    riskLevel: 'Low',
    model: 'Random Forest + Elastic Net',
    status: 'Resolved',
    activitySnapshot: { logins: 7, files: 19, emails: 12, usb: false, afterHours: false }
  }
];
