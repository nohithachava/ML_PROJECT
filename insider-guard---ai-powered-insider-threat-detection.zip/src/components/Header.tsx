import { Menu, ShieldCheck, Download, AlertCircle, Clock } from 'lucide-react';
import { NavTab } from './Sidebar';

interface HeaderProps {
  currentTab: NavTab;
  onOpenMobile: () => void;
  onQuickNavigate: (tab: NavTab) => void;
  onDownloadDataset: () => void;
}

const tabTitles: Record<NavTab, { category: string; title: string }> = {
  dashboard: { category: 'SOC Operations', title: 'Main Dashboard' },
  user_activity: { category: 'Workforce Monitoring', title: 'User Activity' },
  threat_detection: { category: 'ML Inference', title: 'Threat Detection' },
  alerts: { category: 'Incident Response', title: 'Security Alerts' },
  analytics: { category: 'Intelligence & Telemetry', title: 'Analytics' },
  ml_overview: { category: 'Machine Learning', title: 'ML Overview' },
  elastic_net: { category: 'Feature Selection', title: 'Elastic Net Regularization' },
  random_forest: { category: 'Ensemble Classification', title: 'Random Forest Model' },
  model_evaluation: { category: 'Model Performance', title: 'Model Evaluation' },
  monitoring: { category: 'MLOps Pipeline', title: 'System Monitoring' },
  retraining: { category: 'MLOps Automation', title: 'Model Retraining' },
  prediction_history: { category: 'Audit & Telemetry', title: 'Prediction History' },
  raw_dataset: { category: 'Data Repository', title: 'Raw Insider-Activity Dataset' },
  reports: { category: 'Documentation & Defense', title: 'Executive & Technical Reports' },
  settings: { category: 'System Configuration', title: 'Settings' },
  about: { category: 'Academic Defense', title: 'About & Methodology' }
};

export function Header({
  currentTab,
  onOpenMobile,
  onQuickNavigate,
  onDownloadDataset
}: HeaderProps) {
  const info = tabTitles[currentTab] || { category: 'SOC Operations', title: 'Overview' };

  return (
    <header className="h-16 bg-slate-950/80 backdrop-blur-md border-b border-slate-800/80 sticky top-0 z-30 px-4 md:px-6 flex items-center justify-between">
      {/* Left zone: Breadcrumb trail */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobile}
          className="lg:hidden p-1.5 text-slate-400 hover:text-white rounded-lg border border-slate-800"
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 text-xs md:text-sm">
          <span className="text-slate-400 hidden sm:inline">{info.category}</span>
          <span className="text-slate-600 hidden sm:inline">/</span>
          <span className="font-semibold text-slate-100">{info.title}</span>
        </div>
      </div>

      {/* Right zone: Model Status & Actions */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* System Time Pill */}
        <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-[11px] font-mono text-slate-400">
          <Clock className="w-3 h-3 text-slate-500" />
          <span>28 Sep 2026 · SOC LIVE</span>
        </div>

        {/* Model status */}
        <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-[11px] font-mono text-emerald-400">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>RF-EN-v1.0 (Active)</span>
        </div>

        {/* Quick Raw Dataset Download */}
        <button
          onClick={onDownloadDataset}
          title="Download Raw Insider-Activity Dataset (CSV)"
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white text-xs font-mono font-medium rounded-lg border border-slate-700/80 transition-colors cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-slate-400" />
          <span className="hidden sm:inline">Dataset CSV</span>
        </button>

        {/* Quick Inference trigger */}
        {currentTab !== 'threat_detection' && (
          <button
            onClick={() => onQuickNavigate('threat_detection')}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-medium rounded-lg shadow-sm shadow-rose-950 transition-colors cursor-pointer"
          >
            <AlertCircle className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Analyze User Activity</span>
            <span className="sm:hidden">Analyze</span>
          </button>
        )}
      </div>
    </header>
  );
}
