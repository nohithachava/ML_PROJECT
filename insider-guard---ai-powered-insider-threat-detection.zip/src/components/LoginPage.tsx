import React, { useState } from 'react';
import { Shield, Lock, User, ArrowRight, AlertCircle, Sparkles } from 'lucide-react';

interface LoginPageProps {
  onLogin: (username: string) => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [username, setUsername] = useState('analyst@insiderguard.ai');
  const [password, setPassword] = useState('••••••••••••');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      setError('Please provide a valid username or email.');
      return;
    }
    setError(null);
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin(username);
    }, 450);
  };

  const handleQuickDemo = (role: 'analyst' | 'professor') => {
    if (role === 'professor') {
      setUsername('evaluator.prof@university.edu');
    } else {
      setUsername('analyst@insiderguard.ai');
    }
    setPassword('elastic-forest-2026');
    setError(null);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between items-center p-6 relative overflow-hidden select-none">
      {/* Subtle background cyber grid */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{
          backgroundImage: `radial-gradient(circle at 50% 30%, rgba(225, 29, 72, 0.15) 0%, transparent 60%), linear-gradient(to right, #1e293b 1px, transparent 1px), linear-gradient(to bottom, #1e293b 1px, transparent 1px)`,
          backgroundSize: '100% 100%, 48px 48px, 48px 48px'
        }}
      />

      {/* Top spacer */}
      <div className="w-full flex justify-between items-center max-w-5xl z-10 opacity-70">
        <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>SOC MODEL NODE ACTIVE (RF-EN-v1.0)</span>
        </div>
        <div className="text-xs font-mono text-slate-500">
          ML Insider Threat Lab · Academic Defense Edition
        </div>
      </div>

      {/* Main Login Card - Clean, non-overcrowded */}
      <div className="w-full max-w-md z-10">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-8 shadow-2xl backdrop-blur-md relative">
          
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-gradient-to-br from-rose-500/20 to-slate-900 border border-rose-500/30 text-rose-500 mb-4 shadow-lg shadow-rose-950/40">
              <Shield className="w-7 h-7 stroke-[2.2]" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white flex items-center justify-center gap-2">
              INSIDER GUARD
            </h1>
            <p className="text-sm text-slate-400 mt-1 font-medium">
              AI-Powered Insider Threat Detection
            </p>
            <p className="text-[11px] font-mono text-slate-500 mt-0.5">
              Elastic Net Regularization · Random Forest Classifier
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-lg text-xs text-rose-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{error}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Username / Analyst ID
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                  <User className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="analyst@insiderguard.ai"
                  required
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-950/70 border border-slate-700/80 rounded-lg text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-rose-500/40 focus:border-rose-500 transition-all font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  required
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-950/70 border border-slate-700/80 rounded-lg text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-rose-500/40 focus:border-rose-500 transition-all font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full mt-2 py-3 px-4 bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-semibold text-sm rounded-lg shadow-lg shadow-rose-900/40 transition-all flex items-center justify-center gap-2 group cursor-pointer disabled:opacity-60"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <span>LOGIN</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </>
              )}
            </button>
          </form>

          {/* Quick Fill Demo credentials for Professor / Evaluator */}
          <div className="mt-6 pt-5 border-t border-slate-800/80 flex flex-col gap-2">
            <span className="text-[11px] text-slate-400 font-mono text-center flex items-center justify-center gap-1.5">
              <Sparkles className="w-3 h-3 text-amber-400" />
              1-Click Demo Evaluation Profiles:
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemo('analyst')}
                className="px-2.5 py-1.5 text-[11px] bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 rounded text-slate-300 hover:text-white transition-colors text-center cursor-pointer font-mono"
              >
                Security Analyst
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemo('professor')}
                className="px-2.5 py-1.5 text-[11px] bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 rounded text-rose-300 hover:text-rose-200 transition-colors text-center cursor-pointer font-mono"
              >
                Professor / Evaluator
              </button>
            </div>
          </div>

          {/* Footer note */}
          <div className="mt-6 text-center">
            <p className="text-xs text-slate-500 font-mono">
              Secure ML Monitoring System
            </p>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="w-full max-w-5xl z-10 flex flex-col md:flex-row justify-between items-center text-xs text-slate-500 gap-2 border-t border-slate-900 pt-4">
        <span>Dataset: CERT Insider Threat Synthetic Benchmark (1,250 records)</span>
        <span>Feature Selection: Elastic Net · Classifier: Random Forest (200 Trees)</span>
      </div>
    </div>
  );
}
