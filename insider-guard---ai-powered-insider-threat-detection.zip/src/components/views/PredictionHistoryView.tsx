import React, { useState } from 'react';
import { History, Search, Download, Filter, Eye, ChevronRight, X } from 'lucide-react';
import { PredictionHistoryEntry } from '../../types';

interface PredictionHistoryViewProps {
  history: PredictionHistoryEntry[];
  onAnalyzeUser: (userId: string) => void;
}

export function PredictionHistoryView({ history, onAnalyzeUser }: PredictionHistoryViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterOutcome, setFilterOutcome] = useState<'All' | 'Threat' | 'Normal'>('All');
  const [selectedEntry, setSelectedEntry] = useState<PredictionHistoryEntry | null>(null);

  const filteredHistory = history.filter((h) => {
    const matchSearch = h.userId.toLowerCase().includes(searchQuery.toLowerCase());
    const matchOutcome = filterOutcome === 'All' || h.prediction === filterOutcome;
    return matchSearch && matchOutcome;
  });

  const handleExportCsv = () => {
    const headers = ['id', 'date', 'time', 'user_id', 'prediction', 'probability_pct', 'risk_level', 'status'];
    const rows = filteredHistory.map(h => [
      h.id,
      h.date,
      h.time,
      h.userId,
      h.prediction,
      h.probability,
      h.riskLevel,
      h.status
    ].join(','));
    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `prediction_history_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Title & Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Prediction History</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Historical audit log of model classifications, inference timestamps, and confidence scores
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Search */}
          <div className="relative min-w-[160px]">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search user..."
              className="w-full pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-rose-500 font-mono"
            />
          </div>

          {/* Filter */}
          <select
            value={filterOutcome}
            onChange={(e) => setFilterOutcome(e.target.value as any)}
            className="px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-200 font-mono focus:outline-none cursor-pointer"
          >
            <option value="All">All Outcomes</option>
            <option value="Threat">🔴 Threats Only</option>
            <option value="Normal">🟢 Normal Only</option>
          </select>

          {/* Export */}
          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 transition-colors cursor-pointer font-mono"
          >
            <Download className="w-3.5 h-3.5 text-slate-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Table matching user specification:
          Prediction History
          ┌──────────┬────────┬──────────────┬───────────┬─────────┐
          │ Date     │ User   │ Prediction   │ Probability│ Status │
          ├──────────┼────────┼──────────────┼───────────┼─────────┤
          │ 28 Sep   │ U003   │ Threat       │ 87%       │ 🔴      │
          │ 28 Sep   │ U017   │ Normal       │ 12%       │ 🟢      │
          │ 27 Sep   │ U021   │ Threat       │ 71%       │ 🟠      │
          └──────────┴────────┴──────────────┴───────────┴─────────┘
      */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-mono text-[11px] uppercase tracking-wider">
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">User</th>
                <th className="py-3 px-4">Prediction</th>
                <th className="py-3 px-4">Probability</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {filteredHistory.map((item) => {
                const isThreat = item.prediction === 'Threat';
                const isHigh = item.riskLevel === 'High';
                const isMed = item.riskLevel === 'Medium';
                const statusIndicator = isHigh ? '🔴' : isMed ? '🟠' : '🟢';

                return (
                  <tr
                    key={item.id}
                    onClick={() => setSelectedEntry(item)}
                    className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                  >
                    {/* Date */}
                    <td className="py-3 px-4 text-slate-300 font-medium">
                      <span>{item.date}</span>
                      <span className="text-[10px] text-slate-500 ml-1.5">{item.time}</span>
                    </td>

                    {/* User */}
                    <td className="py-3 px-4 font-bold text-slate-100 group-hover:text-rose-400 transition-colors">
                      {item.userId}
                    </td>

                    {/* Prediction */}
                    <td className="py-3 px-4">
                      <span
                        className={`font-semibold ${
                          isThreat ? 'text-rose-400' : 'text-emerald-400'
                        }`}
                      >
                        {item.prediction}
                      </span>
                    </td>

                    {/* Probability */}
                    <td className="py-3 px-4 font-bold text-slate-200">
                      {item.probability}%
                    </td>

                    {/* Status */}
                    <td className="py-3 px-4 text-center text-sm select-none">
                      {statusIndicator}
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedEntry(item);
                        }}
                        className="px-2.5 py-1 text-[11px] bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 transition-colors"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="p-3 bg-slate-950/40 border-t border-slate-800 text-xs text-slate-400 font-mono flex items-center justify-between">
          <span>Showing {filteredHistory.length} audit logs</span>
          <span className="text-[11px] text-slate-500">Classification model: Elastic Net + Random Forest</span>
        </div>
      </div>

      {/* Snapshot Modal */}
      {selectedEntry && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl relative font-mono text-xs">
            <button
              onClick={() => setSelectedEntry(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-white mb-1">
              Prediction Snapshot: {selectedEntry.id}
            </h2>
            <div className="text-slate-400 text-[11px] mb-4">
              Timestamp: {selectedEntry.date} 2026, {selectedEntry.time} UTC
            </div>

            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 mb-4 space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Target User:</span>
                <span className="text-white font-bold">{selectedEntry.userId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Model Decision:</span>
                <span className={selectedEntry.prediction === 'Threat' ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'}>
                  {selectedEntry.prediction} ({selectedEntry.probability}%)
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Classifier:</span>
                <span className="text-slate-200">{selectedEntry.model}</span>
              </div>
            </div>

            <h3 className="text-slate-300 font-bold mb-2">Input Telemetry Vector Snapshot:</h3>
            <div className="space-y-1.5 text-slate-400 bg-slate-950/60 p-3 rounded-lg border border-slate-800/80 mb-5">
              <div className="flex justify-between">
                <span>Login Frequency:</span>
                <span className="text-slate-200">{selectedEntry.activitySnapshot.logins} / day</span>
              </div>
              <div className="flex justify-between">
                <span>File Access Count:</span>
                <span className="text-slate-200">{selectedEntry.activitySnapshot.files} files</span>
              </div>
              <div className="flex justify-between">
                <span>Email Activity:</span>
                <span className="text-slate-200">{selectedEntry.activitySnapshot.emails} emails</span>
              </div>
              <div className="flex justify-between">
                <span>USB Usage:</span>
                <span className={selectedEntry.activitySnapshot.usb ? 'text-rose-400 font-bold' : 'text-slate-200'}>
                  {selectedEntry.activitySnapshot.usb ? 'Yes (Attached)' : 'No'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>After-Hours Activity:</span>
                <span className={selectedEntry.activitySnapshot.afterHours ? 'text-amber-400 font-bold' : 'text-slate-200'}>
                  {selectedEntry.activitySnapshot.afterHours ? 'Yes' : 'No'}
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                const uId = selectedEntry.userId;
                setSelectedEntry(null);
                onAnalyzeUser(uId);
              }}
              className="w-full py-2.5 px-3 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg transition-colors cursor-pointer"
            >
              Re-run Live Inference for {selectedEntry.userId}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
