import React, { useState } from 'react';
import {
  Bell,
  AlertTriangle,
  ShieldCheck,
  ShieldAlert,
  ArrowRight,
  X,
  ExternalLink,
  CheckCircle2,
  Clock,
  User,
  HardDrive,
  FileText
} from 'lucide-react';
import { SecurityAlert, RiskLevel } from '../../types';

interface AlertsViewProps {
  alerts: SecurityAlert[];
  onUpdateAlertStatus: (alertId: string, newStatus: 'Active' | 'Investigating' | 'Resolved') => void;
  onAnalyzeUser: (userId: string) => void;
}

export function AlertsView({
  alerts,
  onUpdateAlertStatus,
  onAnalyzeUser
}: AlertsViewProps) {
  const [filter, setFilter] = useState<'All' | 'High' | 'Medium' | 'Resolved'>('All');
  const [selectedAlert, setSelectedAlert] = useState<SecurityAlert | null>(null);

  const filteredAlerts = alerts.filter((a) => {
    if (filter === 'Resolved') return a.status === 'Resolved';
    if (filter === 'High') return a.riskLevel === 'High' && a.status !== 'Resolved';
    if (filter === 'Medium') return a.riskLevel === 'Medium' && a.status !== 'Resolved';
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header & Filter Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Security Alerts</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Prioritized insider risk queue detected by Random Forest model ensemble
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg">
          <button
            onClick={() => setFilter('All')}
            className={`px-3 py-1.5 text-xs font-mono rounded-md transition-colors cursor-pointer ${
              filter === 'All'
                ? 'bg-slate-800 text-white font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Alerts ({alerts.length})
          </button>
          <button
            onClick={() => setFilter('High')}
            className={`px-3 py-1.5 text-xs font-mono rounded-md transition-colors cursor-pointer ${
              filter === 'High'
                ? 'bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🔴 High Risk
          </button>
          <button
            onClick={() => setFilter('Medium')}
            className={`px-3 py-1.5 text-xs font-mono rounded-md transition-colors cursor-pointer ${
              filter === 'Medium'
                ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🟠 Medium
          </button>
          <button
            onClick={() => setFilter('Resolved')}
            className={`px-3 py-1.5 text-xs font-mono rounded-md transition-colors cursor-pointer ${
              filter === 'Resolved'
                ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🟢 Resolved
          </button>
        </div>
      </div>

      {/* Visually Strong Alert Cards as requested:
          🔴 HIGH RISK
          User U003
          Unusual activity detected
          Risk Probability: 87%
          [ Investigate ]
          
          🟠 MEDIUM RISK
          User U021
          Abnormal file access
          Risk Probability: 64%
          [ Investigate ]

          🟢 RESOLVED
          User U017
          Previous suspicious activity
          Status: Resolved
      */}
      <div className="space-y-4">
        {filteredAlerts.map((alert) => {
          const isResolved = alert.status === 'Resolved';
          const isHigh = alert.riskLevel === 'High' && !isResolved;
          const isMed = alert.riskLevel === 'Medium' && !isResolved;

          return (
            <div
              key={alert.id}
              className={`p-5 rounded-xl border transition-all ${
                isHigh
                  ? 'bg-slate-900/90 border-rose-500/40 hover:border-rose-500/60 shadow-lg shadow-rose-950/20'
                  : isMed
                  ? 'bg-slate-900/90 border-amber-500/40 hover:border-amber-500/60'
                  : 'bg-slate-900/50 border-slate-800 opacity-90'
              }`}
            >
              {/* Top Banner Tag */}
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  {isHigh && (
                    <span className="font-mono text-xs font-bold text-rose-400 tracking-wider flex items-center gap-1.5 uppercase">
                      <span>🔴</span> HIGH RISK
                    </span>
                  )}
                  {isMed && (
                    <span className="font-mono text-xs font-bold text-amber-400 tracking-wider flex items-center gap-1.5 uppercase">
                      <span>🟠</span> MEDIUM RISK
                    </span>
                  )}
                  {isResolved && (
                    <span className="font-mono text-xs font-bold text-emerald-400 tracking-wider flex items-center gap-1.5 uppercase">
                      <span>🟢</span> RESOLVED
                    </span>
                  )}
                </div>

                <div className="text-xs font-mono text-slate-400 flex items-center gap-2">
                  <span>{alert.timestamp}</span>
                  <span>·</span>
                  <span className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-300 font-semibold">
                    {alert.id}
                  </span>
                </div>
              </div>

              {/* Alert Content */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <span className="text-lg font-bold font-mono text-white">
                      User {alert.userId}
                    </span>
                    <span className="text-sm font-semibold text-slate-200">
                      {alert.title}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300">
                    {alert.description}
                  </p>

                  {/* Anomaly Indicators */}
                  <div className="flex flex-wrap items-center gap-2 pt-1 font-mono text-[11px]">
                    {alert.keyAnomalies.map((anom, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-300"
                      >
                        {anom}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Right side Probability & CTA */}
                <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center gap-3 border-t sm:border-t-0 border-slate-800/80 pt-3 sm:pt-0 shrink-0">
                  <div className="text-left sm:text-right font-mono">
                    <div className="text-[11px] text-slate-400">
                      {isResolved ? 'Status:' : 'Risk Probability:'}
                    </div>
                    <div
                      className={`text-2xl font-black ${
                        isResolved
                          ? 'text-emerald-400'
                          : isHigh
                          ? 'text-rose-400'
                          : 'text-amber-400'
                      }`}
                    >
                      {isResolved ? 'Resolved' : `${alert.riskProbability}%`}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setSelectedAlert(alert)}
                      className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm ${
                        isHigh
                          ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-950'
                          : isMed
                          ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-950'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                      }`}
                    >
                      <span>Investigate</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Comprehensive Investigation Modal */}
      {selectedAlert && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-150">
            <button
              onClick={() => setSelectedAlert(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Title */}
            <div className="mb-4">
              <div className="flex items-center gap-2 font-mono text-xs text-rose-400 font-bold uppercase mb-1">
                <span>SOC Incident Triage</span>
                <span>·</span>
                <span>{selectedAlert.id}</span>
              </div>
              <h2 className="text-xl font-bold text-white font-mono flex items-center gap-2">
                <span>User {selectedAlert.userId}</span>
                <span className="text-slate-400 font-sans text-sm font-normal">
                  — {selectedAlert.threatCategory}
                </span>
              </h2>
            </div>

            {/* Summary Box */}
            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 mb-4 font-mono text-xs space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Risk Assessment:</span>
                <span className="text-rose-400 font-bold text-sm">
                  {selectedAlert.riskProbability}% Probability ({selectedAlert.riskLevel} Risk)
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Current Status:</span>
                <span className="text-slate-200 font-semibold">{selectedAlert.status}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Classification Model:</span>
                <span className="text-slate-300">Random Forest Ensemble (200 Trees)</span>
              </div>
            </div>

            {/* Attack Forensics & MITRE ATT&CK */}
            <div className="mb-5 space-y-3">
              <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold">
                Detected Behavioral Anomalies:
              </h3>
              <div className="space-y-1.5 font-mono text-xs">
                {selectedAlert.keyAnomalies.map((a, i) => (
                  <div
                    key={i}
                    className="p-2 rounded bg-slate-950/50 border border-slate-800/80 text-slate-200 flex items-center gap-2"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
                    <span>{a}</span>
                  </div>
                ))}
              </div>

              <div className="p-3 rounded bg-slate-950/50 border border-slate-800 text-[11px] text-slate-400 font-mono">
                <strong className="text-slate-300 block mb-0.5">MITRE ATT&CK Mapping:</strong>
                <span>T1048 (Exfiltration Over Alternative Protocol), T1078 (Valid Accounts / Insider Abuse)</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    onUpdateAlertStatus(selectedAlert.id, 'Resolved');
                    setSelectedAlert(null);
                  }}
                  className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold font-mono rounded-lg transition-colors cursor-pointer text-center"
                >
                  ✓ Mark as Resolved
                </button>
                <button
                  onClick={() => {
                    const uId = selectedAlert.userId;
                    setSelectedAlert(null);
                    onAnalyzeUser(uId);
                  }}
                  className="py-2.5 px-3 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold font-mono rounded-lg transition-colors cursor-pointer text-center"
                >
                  🔬 Run Full ML Audit
                </button>
              </div>

              <button
                onClick={() => {
                  onUpdateAlertStatus(selectedAlert.id, 'Investigating');
                  setSelectedAlert(null);
                }}
                className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono rounded-lg transition-colors cursor-pointer"
              >
                Set Status to Investigating
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
