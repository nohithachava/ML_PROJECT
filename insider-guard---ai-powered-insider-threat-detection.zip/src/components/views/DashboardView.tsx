import { Users, ShieldCheck, AlertTriangle, ShieldAlert, ArrowUpRight, ChevronRight, Activity, Filter } from 'lucide-react';
import { DonutChart, ThreatTrendGraph } from '../shared/Charts';
import { SecurityAlert } from '../../types';
import { NavTab } from '../Sidebar';

interface DashboardViewProps {
  alerts: SecurityAlert[];
  onNavigate: (tab: NavTab) => void;
  onSelectAlert: (alert: SecurityAlert) => void;
  onAnalyzeUser: (userId: string) => void;
}

export function DashboardView({
  alerts,
  onNavigate,
  onSelectAlert,
  onAnalyzeUser
}: DashboardViewProps) {
  // Stat counts matching exact specification:
  // 1,250 Activities | 1,180 Normal | 70 Threats | 23 High Risk
  const stats = [
    {
      title: 'Activities',
      count: '1,250',
      icon: Users,
      color: 'text-slate-300',
      bg: 'bg-slate-900',
      border: 'border-slate-800',
      subtext: 'Logged in last 7 days',
      indicator: '👥'
    },
    {
      title: 'Normal',
      count: '1,180',
      icon: ShieldCheck,
      color: 'text-emerald-400',
      bg: 'bg-slate-900',
      border: 'border-emerald-500/20',
      subtext: '94.4% within baseline',
      indicator: '🟢'
    },
    {
      title: 'Threats',
      count: '70',
      icon: ShieldAlert,
      color: 'text-rose-400',
      bg: 'bg-slate-900',
      border: 'border-rose-500/20',
      subtext: '5.6% anomaly threshold',
      indicator: '🔴'
    },
    {
      title: 'High Risk',
      count: '23',
      icon: AlertTriangle,
      color: 'text-amber-400',
      bg: 'bg-slate-900',
      border: 'border-amber-500/20',
      subtext: 'Immediate SOC review required',
      indicator: '⚠️'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Top Greeting Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 mb-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>SYSTEM MONITORING ONLINE</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-white">
            Good Evening, Security Analyst
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Insider Threat Detection Overview
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-xs text-slate-400 font-mono text-right">
            <span>Last updated: </span>
            <span className="text-slate-200 font-semibold">Today (28 Sep 2026, 14:15 UTC)</span>
          </div>
          <button
            onClick={() => onNavigate('threat_detection')}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-medium transition-colors cursor-pointer shadow-sm shadow-rose-950"
          >
            <span>Analyze User</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 4 Stat Boxes as requested */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s, idx) => {
          return (
            <div
              key={idx}
              className={`p-5 rounded-xl ${s.bg} border ${s.border} transition-all hover:border-slate-700 shadow-sm`}
            >
              <div className="flex items-center justify-between text-xs text-slate-400 font-medium mb-2">
                <span>{s.title}</span>
                <span className="text-sm">{s.indicator}</span>
              </div>
              <div className={`text-3xl font-extrabold font-mono tracking-tight ${s.color}`}>
                {s.count}
              </div>
              <div className="text-[11px] text-slate-400 mt-1.5 font-mono">
                {s.subtext}
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts Row: Threat Trend Graph + Normal vs Threat Donut */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Threat trend graph (2 Cols) */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-semibold text-white">Threat Activity Over Time</h2>
              <p className="text-xs text-slate-400">Weekly aggregate of detected insider anomalies vs baseline</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1 text-[11px] font-mono text-rose-400">
                <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                Threats
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-mono text-slate-400">
                <span className="w-2 h-2 rounded-full bg-slate-600"></span>
                Mon-Sun
              </span>
            </div>
          </div>

          <div className="py-2">
            <ThreatTrendGraph height={210} />
          </div>

          <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span>Peak Incident Window: <strong className="text-rose-400 font-mono">Thursday (18 alerts)</strong></span>
            <button
              onClick={() => onNavigate('analytics')}
              className="text-rose-400 hover:text-rose-300 flex items-center gap-1 font-mono text-[11px] cursor-pointer"
            >
              <span>View Deep Telemetry</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Normal vs Threat Donut (1 Col) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div>
            <h2 className="text-base font-semibold text-white">Normal vs Threat</h2>
            <p className="text-xs text-slate-400">Class balance breakdown across 1,250 records</p>
          </div>

          <div className="my-auto py-4 flex justify-center">
            <DonutChart
              normalPercent={94}
              threatPercent={6}
              size={190}
              centerTitle="94%"
              centerSubtitle="NORMAL"
            />
          </div>

          <div className="pt-3 border-t border-slate-800/80 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-2 text-slate-300">
                <span className="w-2.5 h-2.5 rounded bg-emerald-500"></span>
                <span>Normal Activities</span>
              </span>
              <span className="font-mono text-emerald-400 font-semibold">1,180 (94.4%)</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-2 text-slate-300">
                <span className="w-2.5 h-2.5 rounded bg-rose-500"></span>
                <span>Insider Threats</span>
              </span>
              <span className="font-mono text-rose-400 font-semibold">70 (5.6%)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Security Alerts section */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-semibold text-white">Recent Security Alerts</h2>
            <p className="text-xs text-slate-400">Prioritized triage queue scored by Random Forest classifier</p>
          </div>
          <button
            onClick={() => onNavigate('alerts')}
            className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1 font-medium cursor-pointer"
          >
            <span>View All Alerts ({alerts.length})</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-2.5">
          {alerts.slice(0, 4).map((alert) => {
            const isHigh = alert.riskLevel === 'High';
            const isMedium = alert.riskLevel === 'Medium';
            const badgeIcon = isHigh ? '🔴' : isMedium ? '🟠' : '🟡';
            const badgeBg = isHigh
              ? 'text-rose-400 bg-rose-500/10 border-rose-500/30'
              : isMedium
              ? 'text-amber-400 bg-amber-500/10 border-amber-500/30'
              : 'text-yellow-300 bg-yellow-500/10 border-yellow-500/30';

            return (
              <div
                key={alert.id}
                className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-lg bg-slate-950/60 border border-slate-800 hover:border-slate-700 transition-colors"
              >
                <div className="flex items-start sm:items-center gap-3">
                  <span className="text-base select-none mt-0.5 sm:mt-0">{badgeIcon}</span>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase font-bold ${badgeBg}`}>
                        {alert.riskLevel}
                      </span>
                      <button
                        onClick={() => onAnalyzeUser(alert.userId)}
                        className="text-sm font-semibold font-mono text-white hover:text-rose-400 transition-colors cursor-pointer"
                      >
                        {alert.userId}
                      </button>
                      <span className="text-slate-500 hidden sm:inline">·</span>
                      <span className="text-sm text-slate-200 font-medium">
                        {alert.title}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-slate-400 mt-1 font-mono">
                      <span>Risk: <strong className={isHigh ? 'text-rose-400' : 'text-amber-400'}>{alert.riskProbability}%</strong></span>
                      <span>·</span>
                      <span>{alert.threatCategory}</span>
                      <span>·</span>
                      <span className="text-slate-400">{alert.timestamp}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <button
                    onClick={() => onSelectAlert(alert)}
                    className="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-md border border-slate-700 transition-colors cursor-pointer"
                  >
                    Investigate
                  </button>
                  <button
                    onClick={() => onAnalyzeUser(alert.userId)}
                    className="px-2.5 py-1.5 text-xs font-medium bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 hover:text-white rounded-md border border-rose-500/30 transition-colors cursor-pointer"
                    title="Run direct ML inference on this user"
                  >
                    ML Analyze
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Quick Access Architecture Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
        <div
          onClick={() => onNavigate('elastic_net')}
          className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>Feature Regularization</span>
            <ArrowUpRight className="w-3.5 h-3.5 group-hover:text-rose-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </div>
          <div className="text-sm font-bold text-white">🔬 Elastic Net Pipeline</div>
          <p className="text-slate-400 mt-1 text-[11px] font-sans">
            L1/L2 penalty with L1 ratio 0.5 selecting 8 high-variance threat features from 14 raw signals.
          </p>
        </div>

        <div
          onClick={() => onNavigate('random_forest')}
          className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>Ensemble Classifier</span>
            <ArrowUpRight className="w-3.5 h-3.5 group-hover:text-rose-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </div>
          <div className="text-sm font-bold text-white">🌲 Random Forest (200 Trees)</div>
          <p className="text-slate-400 mt-1 text-[11px] font-sans">
            Gini impurity splitting with balanced class weights resolving 94:6 class imbalance.
          </p>
        </div>

        <div
          onClick={() => onNavigate('raw_dataset')}
          className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>Raw Threat Benchmark</span>
            <ArrowUpRight className="w-3.5 h-3.5 group-hover:text-rose-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </div>
          <div className="text-sm font-bold text-white">💾 CERT-Style Dataset (1,250 Rows)</div>
          <p className="text-slate-400 mt-1 text-[11px] font-sans">
            Downloadable CSV and JSON containing full multidimensional insider activity logs.
          </p>
        </div>
      </div>
    </div>
  );
}
