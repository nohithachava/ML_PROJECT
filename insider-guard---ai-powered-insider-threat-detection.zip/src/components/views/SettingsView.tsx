import React, { useState } from 'react';
import { Settings, Save, Bell, Shield, Sliders, CheckCircle2 } from 'lucide-react';

export function SettingsView() {
  const [threshold, setThreshold] = useState(0.50);
  const [autoIsolate, setAutoIsolate] = useState(true);
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSave = () => {
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>System & Model Settings</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Configure SOC operational thresholds, alert sensitivity, and automated containment policies
          </p>
        </div>
      </div>

      {saveSuccess && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-xs font-mono text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>SOC policy configuration saved and reloaded into model inference runtime.</span>
        </div>
      )}

      {/* Threshold configuration */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4 font-mono text-xs">
        <h2 className="text-sm font-semibold text-white font-sans">
          Threat Classification Threshold (tau)
        </h2>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-slate-300">Decision Cutoff: <strong>{threshold.toFixed(2)}</strong></span>
            <span className="text-slate-500">Default: 0.50</span>
          </div>
          <input
            type="range"
            min="0.20"
            max="0.80"
            step="0.05"
            value={threshold}
            onChange={(e) => setThreshold(Number(e.target.value))}
            className="w-full accent-rose-500 cursor-pointer"
          />
          <p className="text-[11px] text-slate-400 font-sans">
            Lowering threshold increases Recall (catches subtle threats) but raises analyst triage volume.
          </p>
        </div>
      </div>

      {/* Incident Response Automation */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4 text-xs font-mono">
        <h2 className="text-sm font-semibold text-white font-sans">
          Automated Containment & Notification Directives
        </h2>

        <div className="space-y-3">
          <label className="flex items-start gap-3 p-3 rounded-lg bg-slate-950/60 border border-slate-800 cursor-pointer">
            <input
              type="checkbox"
              checked={autoIsolate}
              onChange={(e) => setAutoIsolate(e.target.checked)}
              className="accent-rose-500 mt-0.5"
            />
            <div>
              <span className="text-slate-200 font-semibold block">Automatic Endpoint Isolation on High Risk (&gt;85%)</span>
              <span className="text-[11px] text-slate-400 font-sans block mt-0.5">
                Revokes Active Directory Kerberos tickets and quarantines network switch port.
              </span>
            </div>
          </label>

          <label className="flex items-start gap-3 p-3 rounded-lg bg-slate-950/60 border border-slate-800 cursor-pointer">
            <input
              type="checkbox"
              checked={emailAlerts}
              onChange={(e) => setEmailAlerts(e.target.checked)}
              className="accent-rose-500 mt-0.5"
            />
            <div>
              <span className="text-slate-200 font-semibold block">SOC Lead Email Dispatch</span>
              <span className="text-[11px] text-slate-400 font-sans block mt-0.5">
                Immediately emails security operations leads on new critical detections.
              </span>
            </div>
          </label>
        </div>
      </div>

      <button
        onClick={handleSave}
        className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-mono font-bold transition-colors cursor-pointer flex items-center gap-2"
      >
        <Save className="w-4 h-4" />
        <span>Save Configuration</span>
      </button>
    </div>
  );
}
