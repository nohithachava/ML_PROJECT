import React from 'react';
import { Radio, Activity, Server, Database, Cpu, ShieldCheck, CheckCircle2, TrendingUp, AlertTriangle } from 'lucide-react';
import { ThreatTrendGraph } from '../shared/Charts';

export function MonitoringView() {
  // Specs as requested:
  // Model Version v1.0
  // Model Status 🟢 Healthy
  // Predictions 14,820
  // Average Latency 14 ms
  // Threat Rate 5.6%
  const metrics = [
    { label: 'Model Version', value: 'v1.0', sub: 'Production Active', color: 'text-slate-100' },
    { label: 'Model Status', value: 'Healthy', sub: 'Zero Degraded Nodes', indicator: '🟢', color: 'text-emerald-400' },
    { label: 'Predictions', value: '14,820', sub: 'Inferences Served', color: 'text-slate-100' },
    { label: 'Average Latency', value: '14 ms', sub: '99th Percentile: 22ms', color: 'text-cyan-400' },
    { label: 'Threat Rate', value: '5.6%', sub: 'Within Expected Band', color: 'text-rose-400' }
  ];

  // System Services Health as requested:
  // API 🟢 Online
  // Model 🟢 Loaded
  // Database 🟢 Connected
  // Data Pipeline 🟢 Healthy
  const services = [
    { name: 'API Server', status: 'Online', indicator: '🟢', detail: 'gRPC & REST /api/predict', latency: '4ms' },
    { name: 'Model Engine', status: 'Loaded', indicator: '🟢', detail: 'RandomForest Ensemble in RAM', memory: '142 MB' },
    { name: 'Telemetry Database', status: 'Connected', indicator: '🟢', detail: 'PostgreSQL / Timescale Logs', uptime: '99.98%' },
    { name: 'Data Pipeline', status: 'Healthy', indicator: '🟢', detail: 'Feature Extractor & Normalizer', lag: '0.2s' }
  ];

  // Feature drift analysis data (Population Stability Index - PSI)
  const driftFeatures = [
    { feature: 'File Access Frequency', psi: 0.04, status: 'No Drift', alert: false },
    { feature: 'Removable Storage (USB)', psi: 0.02, status: 'No Drift', alert: false },
    { feature: 'After-Hours Logon Ratio', psi: 0.08, status: 'Stable', alert: false },
    { feature: 'Sensitive Document Read', psi: 0.12, status: 'Mild Drift (Monitored)', alert: true },
    { feature: 'Outbound Data Volume', psi: 0.06, status: 'Stable', alert: false }
  ];

  // Hourly prediction volume data
  const volumeData = [
    { day: '00:00', threats: 2, normal: 85 },
    { day: '04:00', threats: 1, normal: 42 },
    { day: '08:00', threats: 14, normal: 480 },
    { day: '12:00', threats: 19, normal: 540 },
    { day: '16:00', threats: 22, normal: 510 },
    { day: '20:00', threats: 8, normal: 210 },
    { day: '23:00', threats: 4, normal: 95 }
  ];

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Model Monitoring & MLOps</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Production telemetry tracking: latency, throughput, prediction volume, and feature drift
          </p>
        </div>
        <div className="flex items-center gap-2 font-mono text-xs text-emerald-400">
          <Radio className="w-4 h-4 animate-pulse" />
          <span>Real-time Stream Connected</span>
        </div>
      </div>

      {/* Top 5 Stat Boxes as requested:
          Model Version v1.0
          Model Status 🟢 Healthy
          Predictions XXXX
          Average Latency XX ms
          Threat Rate XX%
      */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 font-mono">
        {metrics.map((m, i) => (
          <div
            key={i}
            className="p-4 rounded-xl bg-slate-900 border border-slate-800 shadow-sm"
          >
            <span className="text-xs text-slate-400 block mb-1 font-sans">{m.label}</span>
            <div className={`text-2xl font-black ${m.color} flex items-center gap-1.5`}>
              {m.indicator && <span className="text-sm">{m.indicator}</span>}
              <span>{m.value}</span>
            </div>
            <span className="text-[10px] text-slate-500 block mt-1 truncate">
              {m.sub}
            </span>
          </div>
        ))}
      </div>

      {/* Graphs Row as requested:
          Prediction Volume 📈
          Threat Rate 📈
          Data Drift 📊
      */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* 1. Prediction Volume 📈 */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div className="border-b border-slate-800 pb-3 mb-3 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-white">Prediction Volume</h2>
              <p className="text-[11px] text-slate-400">Total 24h inference request throughput</p>
            </div>
            <span className="text-xs font-mono text-cyan-400 font-bold">14,820 ops</span>
          </div>

          <div className="py-2">
            <ThreatTrendGraph data={volumeData} height={160} />
          </div>

          <div className="pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-400 flex justify-between">
            <span>Peak Hour: 12:00-16:00 UTC</span>
            <span>99.98% Service Availability</span>
          </div>
        </div>

        {/* 2. Threat Rate 📈 */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div className="border-b border-slate-800 pb-3 mb-3 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-white">Threat Rate Stability</h2>
              <p className="text-[11px] text-slate-400">7-day positive alert ratio tracking</p>
            </div>
            <span className="text-xs font-mono text-rose-400 font-bold">5.6% Baseline</span>
          </div>

          <div className="space-y-3 py-2 font-mono text-xs">
            <div className="flex justify-between items-center text-slate-300">
              <span>Upper Threshold Band (Limit):</span>
              <span className="text-rose-400">8.0%</span>
            </div>
            <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden">
              <div style={{ width: '70%' }} className="h-full bg-rose-500 rounded-full" />
            </div>

            <div className="flex justify-between items-center text-slate-300">
              <span>Current Production Rate:</span>
              <span className="text-emerald-400 font-bold">5.6% (Nominal)</span>
            </div>
            <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden">
              <div style={{ width: '56%' }} className="h-full bg-emerald-500 rounded-full" />
            </div>

            <div className="flex justify-between items-center text-slate-300">
              <span>Lower Sensitivity Floor:</span>
              <span className="text-slate-400">3.5%</span>
            </div>
            <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden">
              <div style={{ width: '35%' }} className="h-full bg-slate-700 rounded-full" />
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-400">
            Automated drift alarm triggers if 24h threat rate exceeds <strong>8.0%</strong>.
          </div>
        </div>

        {/* 3. Data Drift 📊 */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div className="border-b border-slate-800 pb-3 mb-3 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-white">Data Drift Monitor</h2>
              <p className="text-[11px] text-slate-400">Population Stability Index (PSI &lt; 0.20)</p>
            </div>
            <span className="text-xs font-mono text-emerald-400 font-bold">All Stable</span>
          </div>

          <div className="space-y-2.5 py-1 font-mono text-xs">
            {driftFeatures.map((df, i) => (
              <div key={i} className="flex items-center justify-between text-slate-300">
                <span className="truncate max-w-[170px] text-slate-400">{df.feature}</span>
                <div className="flex items-center gap-2">
                  <span className={df.alert ? 'text-amber-400 font-bold' : 'text-emerald-400'}>
                    PSI: {df.psi.toFixed(2)}
                  </span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded ${df.alert ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-800 text-slate-400'}`}>
                    {df.status}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-400">
            Kolmogorov-Smirnov Test p-values &gt; 0.05 across all 8 regularized vectors.
          </div>
        </div>

      </div>

      {/* Model Health Section as requested:
          Model Health
          API 🟢 Online
          Model 🟢 Loaded
          Database 🟢 Connected
          Data Pipeline 🟢 Healthy
      */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="border-b border-slate-800 pb-3 mb-4 flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-white">Model Health & Service Topology</h2>
            <p className="text-xs text-slate-400">Continuous health checks and dependencies</p>
          </div>
          <span className="text-xs font-mono text-emerald-400 font-semibold flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4" />
            <span>4 / 4 Services Operational</span>
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
          {services.map((svc, idx) => (
            <div
              key={idx}
              className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/80 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-slate-200">{svc.name}</span>
                  <span className="text-sm">{svc.indicator}</span>
                </div>
                <div className="text-sm font-bold text-emerald-400 mb-1">
                  {svc.status}
                </div>
                <p className="text-[11px] text-slate-400 font-sans">
                  {svc.detail}
                </p>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-800 text-[10px] text-slate-500">
                {svc.latency && `Response: ${svc.latency}`}
                {svc.memory && `RAM Usage: ${svc.memory}`}
                {svc.uptime && `Availability: ${svc.uptime}`}
                {svc.lag && `Pipeline Lag: ${svc.lag}`}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
