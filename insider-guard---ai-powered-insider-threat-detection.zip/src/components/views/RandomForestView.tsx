import React, { useState } from 'react';
import { Trees, Network, CheckCircle2, ChevronRight, Activity, GitBranch, Layers, ShieldCheck } from 'lucide-react';

export function RandomForestView() {
  const [selectedTree, setSelectedTree] = useState<number>(1);

  // Specifications as requested:
  // Trees 200
  // Classification Binary
  // Criterion Gini
  // Class Weight Balanced
  // Model Status 🟢 Active
  const specs = [
    { label: 'Trees', value: '200', sub: 'n_estimators', color: 'text-emerald-400' },
    { label: 'Classification', value: 'Binary', sub: 'Threat (1) vs Normal (0)', color: 'text-slate-100' },
    { label: 'Criterion', value: 'Gini', sub: 'Gini Impurity Splitting', color: 'text-slate-100' },
    { label: 'Class Weight', value: 'Balanced', sub: 'Inverted class frequencies', color: 'text-amber-400' },
    { label: 'Model Status', value: 'Active', sub: 'Inference Ready', indicator: '🟢', color: 'text-emerald-400' }
  ];

  // Feature Importance as requested:
  // File Access █████████████████
  // Login Frequency █████████████
  // Email Activity ██████████
  // USB Usage ███████
  // After Hours █████
  const featureImportances = [
    { name: 'File Access', importance: 0.28, pct: 28, bar: '█████████████████' },
    { name: 'Login Frequency', importance: 0.19, pct: 19, bar: '█████████████' },
    { name: 'Email Activity', importance: 0.15, pct: 15, bar: '██████████' },
    { name: 'USB Usage', importance: 0.14, pct: 14, bar: '███████' },
    { name: 'After Hours', importance: 0.11, pct: 11, bar: '█████' },
    { name: 'Outbound Data (MB)', importance: 0.08, pct: 8, bar: '████' },
    { name: 'Failed Logins', importance: 0.05, pct: 5, bar: '███' }
  ];

  // Sample tree structures for interactive exploration
  const treeNodes: Record<number, { root: string; left: string; right: string; note: string }> = {
    1: {
      root: 'File Access > 30 files? [Gini = 0.485]',
      left: 'Left: USB Usage = True? ➔ If Yes: Threat (Prob 0.89), Else: Normal (Prob 0.14)',
      right: 'Right: Login Freq < 5? ➔ Normal (Prob 0.02)',
      note: 'Tree #1 heavily weights physical peripheral attachment and bulk reads.'
    },
    42: {
      root: 'After-Hours Activity = True? [Gini = 0.462]',
      left: 'Left: Failed Logins > 2? ➔ If Yes: Threat (Prob 0.94), Else: Medium Risk (0.55)',
      right: 'Right: File Access < 20? ➔ Normal (Prob 0.04)',
      note: 'Tree #42 prioritizes off-hours authentication anomalies and brute-force patterns.'
    },
    118: {
      root: 'Outbound Data Volume > 2000 MB? [Gini = 0.441]',
      left: 'Left: External Recipients > 5? ➔ Threat (Prob 0.91)',
      right: 'Right: USB Connected? ➔ If Yes: Threat (Prob 0.72), Else: Normal (0.06)',
      note: 'Tree #118 identifies massive data staging and non-corporate email forwarding.'
    }
  };

  const activeTreeInfo = treeNodes[selectedTree] || treeNodes[1];

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Random Forest Model</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Ensemble decision trees with balanced bootstrapping on Elastic Net regularized features
          </p>
        </div>
        <div className="text-xs font-mono text-emerald-400 flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4" />
          <span>Out-of-Bag (OOB) Accuracy: 96.8%</span>
        </div>
      </div>

      {/* Random Forest Model Spec Bar as requested:
          Random Forest Model
          Trees 200
          Classification Binary
          Criterion Gini
          Class Weight Balanced
          Model Status 🟢 Active
      */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm">
        <h2 className="text-xs font-mono text-slate-400 uppercase tracking-widest mb-3">
          Random Forest Model Hyperparameters & Architecture
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {specs.map((s, i) => (
            <div
              key={i}
              className="p-3 rounded-lg bg-slate-950/70 border border-slate-800/80 font-mono text-xs"
            >
              <span className="text-slate-400 block text-[11px] mb-1">{s.label}</span>
              <div className={`text-xl font-bold tracking-tight ${s.color} flex items-center gap-1.5`}>
                {s.indicator && <span className="text-sm">{s.indicator}</span>}
                <span>{s.value}</span>
              </div>
              <span className="text-[10px] text-slate-500 block mt-1 truncate">
                {s.sub}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Feature Importance as requested:
          Feature Importance
          File Access █████████████████
          Login Frequency █████████████
          Email Activity ██████████
          USB Usage ███████
          After Hours █████
      */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div className="border-b border-slate-800 pb-3 mb-5 flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-white">Feature Importance</h2>
            <p className="text-xs text-slate-400">
              Mean Decrease in Impurity (MDI / Gini Importance) across 200 ensemble trees
            </p>
          </div>
          <span className="text-xs font-mono text-emerald-400 font-semibold">
            Normalized $\sum = 1.00$
          </span>
        </div>

        <div className="space-y-4 font-mono text-xs">
          {featureImportances.map((item, idx) => (
            <div key={idx} className="space-y-1.5">
              <div className="flex justify-between items-center text-slate-300">
                <span className="font-semibold flex items-center gap-2">
                  <span className="text-slate-500 text-[10px]">{idx + 1}.</span>
                  <span>{item.name}</span>
                </span>
                <div className="flex items-center gap-3">
                  <span className="text-rose-400/80 font-mono select-all hidden sm:inline text-[11px]">
                    {item.bar}
                  </span>
                  <span className="text-white font-bold w-12 text-right">
                    {item.pct}%
                  </span>
                </div>
              </div>

              {/* Graphical Bar */}
              <div className="h-3 w-full bg-slate-950 rounded-md overflow-hidden flex items-center p-0.5">
                <div
                  style={{ width: `${item.pct * 3}%` }}
                  className="h-full bg-gradient-to-r from-emerald-600 via-rose-500 to-rose-600 rounded-xs transition-all duration-700"
                />
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-2">
          <span>
            💡 <strong>File Access</strong> & <strong>Login Frequency</strong> drive over <strong>47%</strong> of all ensemble splitting decisions.
          </span>
          <span className="font-mono text-slate-500 text-[11px]">
            Formula: MDI(f) = (1/T) &Sigma; &Delta;Gini(split on f)
          </span>
        </div>
      </div>

      {/* Interactive Ensemble Decision Tree Inspector */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 mb-4 border-b border-slate-800">
          <div>
            <h2 className="text-base font-semibold text-white flex items-center gap-2">
              <GitBranch className="w-4 h-4 text-emerald-400" />
              <span>Interactive Decision Tree Inspector</span>
            </h2>
            <p className="text-xs text-slate-400">
              Inspect how individual bootstrap trees in the 200-tree forest split and vote
            </p>
          </div>

          <div className="flex items-center gap-1.5 font-mono text-xs">
            <span className="text-slate-400 mr-1">Select Tree:</span>
            {[1, 42, 118].map((tNum) => (
              <button
                key={tNum}
                onClick={() => setSelectedTree(tNum)}
                className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                  selectedTree === tNum
                    ? 'bg-emerald-600 text-white font-bold'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                Tree #{tNum}
              </button>
            ))}
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 font-mono text-xs">
          <div className="flex items-center justify-between">
            <span className="text-emerald-400 font-bold">
              🌲 Tree #{selectedTree} Decision Node Topology
            </span>
            <span className="text-slate-500 text-[11px]">Max Depth: 12 · Min Samples Split: 5</span>
          </div>

          <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800 text-slate-200">
            <strong className="text-amber-400 block mb-1">Root Decision Node:</strong>
            <span>{activeTreeInfo.root}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800/80 text-rose-300">
              {activeTreeInfo.left}
            </div>
            <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800/80 text-emerald-300">
              {activeTreeInfo.right}
            </div>
          </div>

          <p className="text-[11px] text-slate-400 font-sans pt-1">
            {activeTreeInfo.note}
          </p>
        </div>
      </div>
    </div>
  );
}
