import React, { useState } from 'react';
import { DonutChart, ThreatTrendGraph } from '../shared/Charts';
import { BarChart3, TrendingUp, Network, PieChart, Flame, Info } from 'lucide-react';

export function AnalyticsView() {
  const [selectedCell, setSelectedCell] = useState<{
    f1: string;
    f2: string;
    val: number;
    desc: string;
  } | null>(null);

  // Department activity data
  const deptData = [
    { name: 'Engineering', normal: 420, threats: 28, rate: '6.2%' },
    { name: 'IT Infrastructure', normal: 260, threats: 22, rate: '7.8%' },
    { name: 'Finance', normal: 210, threats: 11, rate: '4.9%' },
    { name: 'Sales & Ops', normal: 180, threats: 6, rate: '3.2%' },
    { name: 'Human Resources', normal: 110, threats: 3, rate: '2.6%' }
  ];

  // Correlation Matrix data (Pearson r between -1.0 and +1.0)
  const features = ['Logins', 'File Access', 'Sens. Files', 'USB Usage', 'After-Hours', 'Data (MB)', 'Threat'];
  const correlationMatrix = [
    [1.00, 0.42, 0.38, 0.28, 0.31, 0.35, 0.52],
    [0.42, 1.00, 0.82, 0.64, 0.58, 0.74, 0.86],
    [0.38, 0.82, 1.00, 0.69, 0.62, 0.79, 0.89],
    [0.28, 0.64, 0.69, 1.00, 0.51, 0.71, 0.76],
    [0.31, 0.58, 0.62, 0.51, 1.00, 0.65, 0.74],
    [0.35, 0.74, 0.79, 0.71, 0.65, 1.00, 0.81],
    [0.52, 0.86, 0.89, 0.76, 0.74, 0.81, 1.00]
  ];

  // Color mapper for correlation heatmap
  const getHeatmapColor = (val: number) => {
    if (val >= 0.8) return 'bg-rose-600 text-white font-bold';
    if (val >= 0.6) return 'bg-rose-500/70 text-white font-semibold';
    if (val >= 0.4) return 'bg-rose-500/40 text-rose-200';
    if (val >= 0.2) return 'bg-rose-500/20 text-rose-300';
    return 'bg-slate-800/80 text-slate-400';
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Security & ML Analytics</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Multivariate behavioral analytics, threat category distribution, and telemetry correlations
          </p>
        </div>
        <div className="text-xs font-mono text-slate-400">
          Dataset: CERT Insider Activity · 1,250 Entities
        </div>
      </div>

      {/* 2x2 Grid Layout as explicitly requested:
          ┌─────────────────────────┐ ┌─────────────────────────┐
          │ Threat Distribution     │ │ Threats Over Time       │
          │                         │ │                         │
          │ 🍩 CHART                │ │ 📈 GRAPH                │
          └─────────────────────────┘ └─────────────────────────┘
          ┌─────────────────────────┐ ┌─────────────────────────┐
          │ User Activity           │ │ Activity Correlation    │
          │                         │ │                         │
          │ 📊 BAR CHART            │ │ 🔥 HEATMAP              │
          └─────────────────────────┘ └─────────────────────────┘
      */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* 1. Threat Distribution (🍩 CHART) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div className="border-b border-slate-800 pb-3 mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-base font-semibold text-white flex items-center gap-2">
                <span>Threat Distribution</span>
              </h2>
              <p className="text-xs text-slate-400">Proportion of insider attacks by threat taxonomy</p>
            </div>
            <PieChart className="w-4 h-4 text-slate-400" />
          </div>

          <div className="py-2 flex flex-col sm:flex-row items-center justify-around gap-6">
            <DonutChart
              normalPercent={42}
              threatPercent={58}
              size={170}
              strokeWidth={22}
              centerTitle="42%"
              centerSubtitle="EXFILTRATION"
            />

            <div className="space-y-2 text-xs font-mono w-full sm:w-auto">
              <div className="flex items-center justify-between gap-4 p-1.5 rounded bg-slate-950/60 border border-slate-800">
                <span className="flex items-center gap-2 text-slate-300">
                  <span className="w-2.5 h-2.5 rounded bg-rose-500"></span>
                  Data Exfiltration
                </span>
                <span className="text-rose-400 font-bold">29 (41.4%)</span>
              </div>
              <div className="flex items-center justify-between gap-4 p-1.5 rounded bg-slate-950/60 border border-slate-800">
                <span className="flex items-center gap-2 text-slate-300">
                  <span className="w-2.5 h-2.5 rounded bg-amber-500"></span>
                  Privilege Escalation
                </span>
                <span className="text-amber-400 font-bold">19 (27.1%)</span>
              </div>
              <div className="flex items-center justify-between gap-4 p-1.5 rounded bg-slate-950/60 border border-slate-800">
                <span className="flex items-center gap-2 text-slate-300">
                  <span className="w-2.5 h-2.5 rounded bg-cyan-500"></span>
                  Unauthorized Access
                </span>
                <span className="text-cyan-400 font-bold">13 (18.6%)</span>
              </div>
              <div className="flex items-center justify-between gap-4 p-1.5 rounded bg-slate-950/60 border border-slate-800">
                <span className="flex items-center gap-2 text-slate-300">
                  <span className="w-2.5 h-2.5 rounded bg-indigo-500"></span>
                  IP & Source Theft
                </span>
                <span className="text-indigo-400 font-bold">9 (12.9%)</span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800/80 text-[11px] text-slate-400 font-mono">
            Key finding: <strong>68.5%</strong> of detected threat vectors involve bulk staging of sensitive files to physical USB or outbound relays.
          </div>
        </div>

        {/* 2. Threats Over Time (📈 GRAPH) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div className="border-b border-slate-800 pb-3 mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-base font-semibold text-white flex items-center gap-2">
                <span>Threats Over Time</span>
              </h2>
              <p className="text-xs text-slate-400">Weekly temporal fluctuation of anomalous behaviors</p>
            </div>
            <TrendingUp className="w-4 h-4 text-slate-400" />
          </div>

          <div className="py-2">
            <ThreatTrendGraph height={180} />
          </div>

          <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>Baseline Threat Rate: <strong>5.6%</strong></span>
            <span className="text-rose-400">Thursday Peak: 18 Anomaly Events</span>
          </div>
        </div>

        {/* 3. User Activity (📊 BAR CHART) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div className="border-b border-slate-800 pb-3 mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-base font-semibold text-white flex items-center gap-2">
                <span>User Activity by Department</span>
              </h2>
              <p className="text-xs text-slate-400">Normal vs Threat activity volume by corporate division</p>
            </div>
            <BarChart3 className="w-4 h-4 text-slate-400" />
          </div>

          <div className="space-y-3.5 py-2 font-mono text-xs">
            {deptData.map((d, i) => {
              const total = d.normal + d.threats;
              const normalPct = (d.normal / total) * 100;
              const threatPct = (d.threats / total) * 100;

              return (
                <div key={i} className="space-y-1">
                  <div className="flex justify-between text-slate-300">
                    <span className="font-semibold">{d.name}</span>
                    <span className="text-slate-400">
                      {d.normal} normal / <strong className="text-rose-400">{d.threats} threats</strong> ({d.rate})
                    </span>
                  </div>
                  <div className="h-3 w-full bg-slate-800 rounded-md overflow-hidden flex">
                    <div
                      style={{ width: `${normalPct}%` }}
                      className="bg-emerald-500/80 transition-all duration-500"
                      title={`${d.normal} Normal activities`}
                    />
                    <div
                      style={{ width: `${threatPct}%` }}
                      className="bg-rose-500 transition-all duration-500"
                      title={`${d.threats} Threat activities`}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-3 border-t border-slate-800/80 flex items-center gap-4 text-xs font-mono">
            <span className="flex items-center gap-1.5 text-slate-400">
              <span className="w-2.5 h-2.5 rounded bg-emerald-500"></span> Normal Activities
            </span>
            <span className="flex items-center gap-1.5 text-slate-400">
              <span className="w-2.5 h-2.5 rounded bg-rose-500"></span> Threats Flagged
            </span>
          </div>
        </div>

        {/* 4. Activity Correlation (🔥 HEATMAP) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div className="border-b border-slate-800 pb-3 mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-base font-semibold text-white flex items-center gap-2">
                <span>Activity Correlation Matrix</span>
              </h2>
              <p className="text-xs text-slate-400">Pairwise Pearson correlation coefficients (r)</p>
            </div>
            <Flame className="w-4 h-4 text-rose-500" />
          </div>

          <div className="overflow-x-auto py-1">
            <table className="w-full text-center text-[10px] font-mono border-collapse">
              <thead>
                <tr>
                  <th className="p-1 text-left text-slate-400"></th>
                  {features.map((f, i) => (
                    <th key={i} className="p-1 text-slate-400 font-semibold truncate max-w-[50px]">
                      {f}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {correlationMatrix.map((row, rIdx) => (
                  <tr key={rIdx}>
                    <td className="p-1 text-left text-slate-300 font-semibold whitespace-nowrap">
                      {features[rIdx]}
                    </td>
                    {row.map((val, cIdx) => (
                      <td
                        key={cIdx}
                        onClick={() =>
                          setSelectedCell({
                            f1: features[rIdx],
                            f2: features[cIdx],
                            val,
                            desc:
                              val > 0.75
                                ? 'Strong positive co-movement and mutual information'
                                : val > 0.5
                                ? 'Moderate statistical correlation'
                                : 'Mild or uncorrelated baseline variation'
                          })
                        }
                        className={`p-1.5 border border-slate-900 rounded-xs cursor-pointer transition-transform hover:scale-105 ${getHeatmapColor(
                          val
                        )}`}
                        title={`${features[rIdx]} vs ${features[cIdx]}: r = ${val.toFixed(2)}`}
                      >
                        {val.toFixed(2)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400">
            {selectedCell ? (
              <span className="text-rose-300">
                {selectedCell.f1} ↔ {selectedCell.f2}: <strong>r = {selectedCell.val.toFixed(2)}</strong> ({selectedCell.desc})
              </span>
            ) : (
              <span>Click any heatmap cell to view coefficient explanation</span>
            )}
            <span className="text-slate-500 hidden sm:inline">Scale: 0.0 (Low) to 1.0 (High)</span>
          </div>
        </div>

      </div>
    </div>
  );
}
