import React, { useState } from 'react';
import { Download, FileSpreadsheet, Search, Filter, Copy, Check, Info, FileCode } from 'lucide-react';
import { UserActivityRecord } from '../../types';
import { generateDatasetCsv } from '../../data/dataset';

interface RawDatasetViewProps {
  records: UserActivityRecord[];
}

export function RawDatasetView({ records }: RawDatasetViewProps) {
  const [search, setSearch] = useState('');
  const [filterDept, setFilterDept] = useState('All');
  const [filterLabel, setFilterLabel] = useState('All');
  const [currentPage, setCurrentPage] = useState(1);
  const [copied, setCopied] = useState(false);
  const pageSize = 25;

  const filtered = records.filter(r => {
    const matchSearch = r.userId.toLowerCase().includes(search.toLowerCase()) ||
      r.role.toLowerCase().includes(search.toLowerCase());
    const matchDept = filterDept === 'All' || r.department === filterDept;
    const matchLabel = filterLabel === 'All' || r.threatLabel === filterLabel;
    return matchSearch && matchDept && matchLabel;
  });

  const totalPages = Math.ceil(filtered.length / pageSize);
  const paginatedRows = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const handleDownloadCsv = () => {
    const csvData = generateDatasetCsv(records);
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `insider_activity_dataset_1250_records.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadJson = () => {
    const jsonData = JSON.stringify(records, null, 2);
    const blob = new Blob([jsonData], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `insider_activity_dataset_1250_records.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopySample = () => {
    const sampleCsv = generateDatasetCsv(records.slice(0, 15));
    navigator.clipboard.writeText(sampleCsv);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Raw Insider-Activity Dataset Repository</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Synthetic CERT-standard benchmark dataset for training and validating Elastic Net and Random Forest models
          </p>
        </div>

        {/* Download Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleCopySample}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg text-xs font-mono text-slate-200 transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Sample Copied' : 'Copy Sample'}</span>
          </button>

          <button
            onClick={handleDownloadJson}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg text-xs font-mono text-cyan-300 transition-colors cursor-pointer"
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Download JSON</span>
          </button>

          <button
            onClick={handleDownloadCsv}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-mono font-bold transition-colors cursor-pointer shadow-sm shadow-rose-950"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Dataset (CSV)</span>
          </button>
        </div>
      </div>

      {/* Dataset Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-slate-400 block mb-1">Total Instances</span>
          <div className="text-2xl font-bold text-white">1,250</div>
          <span className="text-[11px] text-slate-500 font-sans mt-1 block">
            Workforce Activity Records
          </span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-slate-400 block mb-1">Normal Baseline</span>
          <div className="text-2xl font-bold text-emerald-400">1,180</div>
          <span className="text-[11px] text-slate-500 font-sans mt-1 block">
            94.4% Majority Class
          </span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-slate-400 block mb-1">Insider Threats</span>
          <div className="text-2xl font-bold text-rose-400">70</div>
          <span className="text-[11px] text-slate-500 font-sans mt-1 block">
            5.6% Minority Class (23 High)
          </span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-slate-400 block mb-1">Feature Dimension</span>
          <div className="text-2xl font-bold text-cyan-400">14 Features</div>
          <span className="text-[11px] text-slate-500 font-sans mt-1 block">
            8 Selected by Elastic Net
          </span>
        </div>
      </div>

      {/* Data Dictionary Accordion / Reference */}
      <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs font-mono">
        <div className="flex items-center gap-2 text-slate-200 font-bold mb-2">
          <Info className="w-4 h-4 text-rose-400" />
          <span>Feature Data Dictionary & Measurement Standards:</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 text-[11px] text-slate-400">
          <div><code className="text-rose-300">user_id</code>: Unique employee identifier (U001 to U1250)</div>
          <div><code className="text-rose-300">login_frequency</code>: Distinct daily authentication requests</div>
          <div><code className="text-rose-300">file_access_count</code>: Total file read/write operations</div>
          <div><code className="text-rose-300">sensitive_files</code>: Access to confidential/classified vaults</div>
          <div><code className="text-rose-300">email_activity</code>: Outbound email messages dispatched</div>
          <div><code className="text-rose-300">usb_usage</code>: Binary flag (1 = Mounted, 0 = None)</div>
          <div><code className="text-rose-300">after_hours</code>: Activity outside 08:00 - 18:00 window</div>
          <div><code className="text-rose-300">data_transfer_mb</code>: Aggregate data staged/egressed</div>
          <div><code className="text-rose-300">threat_label</code>: Target truth classification label</div>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 font-mono text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search user or role..."
              className="w-full pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:border-rose-500 text-xs"
            />
          </div>

          <select
            value={filterDept}
            onChange={(e) => {
              setFilterDept(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-slate-300"
          >
            <option value="All">All Departments</option>
            <option value="Engineering">Engineering</option>
            <option value="IT">IT Infrastructure</option>
            <option value="Finance">Finance</option>
            <option value="Sales">Sales</option>
            <option value="Human Resources">HR</option>
          </select>

          <select
            value={filterLabel}
            onChange={(e) => {
              setFilterLabel(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-slate-300"
          >
            <option value="All">All Labels</option>
            <option value="Threat">Threat Instances (70)</option>
            <option value="Normal">Normal Baseline (1,180)</option>
          </select>
        </div>

        <div className="text-slate-400 text-xs">
          Showing <strong>{filtered.length}</strong> matching records
        </div>
      </div>

      {/* Raw Data Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/80 text-slate-400 text-[11px] uppercase tracking-wider whitespace-nowrap">
                <th className="py-3 px-3">user_id</th>
                <th className="py-3 px-3">dept</th>
                <th className="py-3 px-3">role</th>
                <th className="py-3 px-3 text-right">login_freq</th>
                <th className="py-3 px-3 text-right">file_access</th>
                <th className="py-3 px-3 text-right">sens_files</th>
                <th className="py-3 px-3 text-right">emails</th>
                <th className="py-3 px-3 text-center">usb</th>
                <th className="py-3 px-3 text-center">after_hours</th>
                <th className="py-3 px-3 text-right">data_mb</th>
                <th className="py-3 px-3 text-center">threat_score</th>
                <th className="py-3 px-3 text-center">threat_label</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {paginatedRows.map((r) => {
                const isThreat = r.threatLabel === 'Threat';
                return (
                  <tr key={r.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-3 font-bold text-white">{r.userId}</td>
                    <td className="py-2.5 px-3 text-slate-400">{r.department}</td>
                    <td className="py-2.5 px-3 text-slate-300 truncate max-w-[140px]">{r.role}</td>
                    <td className="py-2.5 px-3 text-right">{r.loginFrequency}</td>
                    <td className="py-2.5 px-3 text-right">{r.fileAccessCount}</td>
                    <td className="py-2.5 px-3 text-right">{r.sensitiveFilesAccessed}</td>
                    <td className="py-2.5 px-3 text-right">{r.emailActivity}</td>
                    <td className="py-2.5 px-3 text-center">
                      {r.usbUsage ? (
                        <span className="text-rose-400 font-bold">1</span>
                      ) : (
                        <span className="text-slate-600">0</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      {r.afterHoursActivity ? (
                        <span className="text-amber-400 font-bold">1</span>
                      ) : (
                        <span className="text-slate-600">0</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right">{r.dataTransferMB}</td>
                    <td className="py-2.5 px-3 text-center font-bold">
                      <span className={isThreat ? 'text-rose-400' : 'text-slate-400'}>
                        {r.threatScore.toFixed(3)}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                          isThreat
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        }`}
                      >
                        {r.threatLabel}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="p-3 bg-slate-950/60 border-t border-slate-800 font-mono text-xs flex items-center justify-between">
          <span className="text-slate-400">
            Page {currentPage} of {totalPages || 1}
          </span>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 hover:bg-slate-700 disabled:opacity-40 cursor-pointer"
            >
              Previous
            </button>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages || totalPages === 0}
              className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 hover:bg-slate-700 disabled:opacity-40 cursor-pointer"
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
