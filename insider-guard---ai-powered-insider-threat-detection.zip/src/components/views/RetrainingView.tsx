import React, { useState } from 'react';
import { RefreshCw, CheckCircle2, Play, ArrowRight, ShieldCheck, Cpu, HardDrive } from 'lucide-react';

export function RetrainingView() {
  const [isRetraining, setIsRetraining] = useState(false);
  const [progress, setProgress] = useState(0);
  const [activeStep, setActiveStep] = useState<string>('');
  const [completed, setCompleted] = useState(false);
  const [currentVersion, setCurrentVersion] = useState('v1.0');
  const [newVersion, setNewVersion] = useState<string | null>(null);

  // Specifications as requested:
  // Current Model: Version: v1.0
  // Training Dataset: Records: 1,250
  // Last Training: Date: 28/09/2026
  const currentModel = {
    version: currentVersion,
    records: 1250,
    lastDate: '28/09/2026',
    f1Score: '93.3%',
    trees: 200,
    l1Ratio: 0.50
  };

  const handleStartRetraining = () => {
    setIsRetraining(true);
    setProgress(0);
    setCompleted(false);
    setNewVersion(null);

    // Multi-phase training simulation
    const steps = [
      { pct: 15, msg: 'Ingesting 1,250 activity records & computing Z-scores...' },
      { pct: 35, msg: 'Running Elastic Net feature selection (L1 ratio = 0.50)...' },
      { pct: 60, msg: 'Bootstrapping dataset and training 200 Decision Trees...' },
      { pct: 85, msg: 'Calculating Out-of-Bag (OOB) error & Gini splits...' },
      { pct: 90, msg: 'Running 5-fold stratified cross-validation...' },
      { pct: 100, msg: 'Validation completed. Model calibrated and packaged.' }
    ];

    let currentStepIdx = 0;
    const interval = setInterval(() => {
      if (currentStepIdx < steps.length) {
        setProgress(steps[currentStepIdx].pct);
        setActiveStep(steps[currentStepIdx].msg);
        currentStepIdx++;
      } else {
        clearInterval(interval);
        setIsRetraining(false);
        setCompleted(true);
        setNewVersion('v1.1');
      }
    }, 450);
  };

  const handleDeployNewVersion = () => {
    if (newVersion) {
      setCurrentVersion(newVersion);
      setNewVersion(null);
      setCompleted(false);
      setProgress(0);
    }
  };

  // Helper for rendering ASCII-style block progress: ██████████████████░░ 90%
  const renderAsciiProgressBar = (pct: number) => {
    const totalBlocks = 20;
    const filledBlocks = Math.round((pct / 100) * totalBlocks);
    const emptyBlocks = totalBlocks - filledBlocks;
    return '█'.repeat(filledBlocks) + '░'.repeat(emptyBlocks);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Model Retraining Pipeline</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Automated retraining on updated workforce activity records
          </p>
        </div>
        <div className="text-xs font-mono text-slate-400">
          MLOps Automation · Model Registry
        </div>
      </div>

      {/* Main Retraining Card as requested:
          Model Retraining
          Current Model
          Version: v1.0
          Training Dataset
          Records: XXXX
          Last Training
          Date: XX/XX/XXXX
      */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 shadow-sm max-w-2xl">
        <h2 className="text-xs font-mono uppercase tracking-widest text-slate-400 font-bold mb-4">
          Current Model Status
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono text-xs mb-6">
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-slate-400 block mb-1">Current Model</span>
            <div className="text-2xl font-bold text-white">
              {currentModel.version}
            </div>
            <span className="text-[11px] text-emerald-400 font-sans mt-1 block">
              Active in SOC
            </span>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-slate-400 block mb-1">Training Dataset</span>
            <div className="text-2xl font-bold text-slate-200">
              {currentModel.records}
            </div>
            <span className="text-[11px] text-slate-500 font-sans mt-1 block">
              Records Processed
            </span>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-slate-400 block mb-1">Last Training</span>
            <div className="text-xl font-bold text-slate-200">
              {currentModel.lastDate}
            </div>
            <span className="text-[11px] text-slate-500 font-sans mt-1 block">
              14:00 UTC
            </span>
          </div>
        </div>

        {/* [ START RETRAINING ] CTA button */}
        {!isRetraining && !completed && (
          <button
            onClick={handleStartRetraining}
            className="w-full py-3 px-4 bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-bold text-xs uppercase tracking-wider rounded-lg shadow-lg shadow-rose-950/60 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>START RETRAINING</span>
          </button>
        )}

        {/* Retraining in progress or completed */}
        {(isRetraining || completed) && (
          <div className="space-y-5 pt-2 font-mono">
            {/* Training Progress as requested:
                Training Progress
                ██████████████████░░ 90%
            */}
            <div>
              <div className="flex justify-between items-center text-xs text-slate-300 mb-2">
                <span className="font-semibold uppercase tracking-wider">
                  Training Progress
                </span>
                <span className="text-rose-400 font-bold">{progress}%</span>
              </div>

              {/* ASCII Block Visual Bar */}
              <div className="text-rose-400 font-bold tracking-widest text-lg select-all bg-slate-950 p-3 rounded-lg border border-slate-800 text-center">
                {renderAsciiProgressBar(progress)} {progress}%
              </div>

              {activeStep && (
                <p className="text-[11px] text-slate-400 mt-2 font-sans">
                  {activeStep}
                </p>
              )}
            </div>

            {/* Validation & New Model as requested:
                Validation
                🟢 Passed
                New Model
                Version: v1.1
            */}
            {completed && (
              <div className="p-4 rounded-xl bg-slate-950 border border-emerald-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">Validation:</span>
                  <span className="text-emerald-400 font-bold text-sm flex items-center gap-1.5">
                    <span>🟢</span> Passed (Cross-Validation Score: 93.9% F1)
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">New Model:</span>
                  <span className="text-white font-bold text-sm">
                    Version: {newVersion}
                  </span>
                </div>

                <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400 font-sans">
                    +0.6% F1 gain on minority threat recall
                  </span>
                  <button
                    onClick={handleDeployNewVersion}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-md text-xs font-bold transition-colors cursor-pointer"
                  >
                    Deploy {newVersion} to Production
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
