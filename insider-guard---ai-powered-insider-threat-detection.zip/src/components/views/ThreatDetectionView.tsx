import React, { useState, useEffect } from 'react';
import {
  Search,
  Sparkles,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  RotateCcw,
  Zap,
  CheckCircle2,
  Lock,
  Layers,
  Info
} from 'lucide-react';
import { PredictionResult, UserActivityRecord } from '../../types';
import { predictInsiderThreat, ActivityInferenceInput } from '../../ml/models';
import { RiskGauge } from '../shared/Charts';

interface ThreatDetectionViewProps {
  initialUserId?: string;
  initialRecord?: UserActivityRecord;
  onRecordPrediction?: (result: PredictionResult) => void;
}

export function ThreatDetectionView({
  initialUserId,
  initialRecord,
  onRecordPrediction
}: ThreatDetectionViewProps) {
  // Input fields as requested:
  // User ID [ U003 ]
  // Login Frequency [ 8 ]
  // File Access [ 42 ]
  // Email Activity [ 17 ]
  // USB Usage [ Yes ]
  // After-hours Activity [ Yes ]
  const [userId, setUserId] = useState(initialUserId || 'U003');
  const [loginFrequency, setLoginFrequency] = useState(8);
  const [fileAccessCount, setFileAccessCount] = useState(42);
  const [emailActivity, setEmailActivity] = useState(17);
  const [usbUsage, setUsbUsage] = useState(true);
  const [afterHoursActivity, setAfterHoursActivity] = useState(true);

  // Advanced features (auto-adjusted or toggleable)
  const [sensitiveFiles, setSensitiveFiles] = useState(18);
  const [failedLogins, setFailedLogins] = useState(4);
  const [dataTransferMB, setDataTransferMB] = useState(4850);

  // ML Analysis State
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);

  // Sync initialRecord if passed from User Activity view
  useEffect(() => {
    if (initialRecord) {
      setUserId(initialRecord.userId);
      setLoginFrequency(initialRecord.loginFrequency);
      setFileAccessCount(initialRecord.fileAccessCount);
      setEmailActivity(initialRecord.emailActivity);
      setUsbUsage(initialRecord.usbUsage);
      setAfterHoursActivity(initialRecord.afterHoursActivity);
      setSensitiveFiles(initialRecord.sensitiveFilesAccessed);
      setFailedLogins(initialRecord.failedLogins);
      setDataTransferMB(initialRecord.dataTransferMB);

      // Auto-run analysis on user load
      const res = predictInsiderThreat({
        userId: initialRecord.userId,
        loginFrequency: initialRecord.loginFrequency,
        fileAccessCount: initialRecord.fileAccessCount,
        sensitiveFilesAccessed: initialRecord.sensitiveFilesAccessed,
        emailActivity: initialRecord.emailActivity,
        usbUsage: initialRecord.usbUsage,
        afterHoursActivity: initialRecord.afterHoursActivity,
        failedLogins: initialRecord.failedLogins,
        dataTransferMB: initialRecord.dataTransferMB
      });
      setPrediction(res);
    } else {
      // Default initial inference on U003
      const res = predictInsiderThreat({
        userId: 'U003',
        loginFrequency: 8,
        fileAccessCount: 42,
        sensitiveFilesAccessed: 18,
        emailActivity: 17,
        usbUsage: true,
        afterHoursActivity: true,
        failedLogins: 4,
        dataTransferMB: 4850
      });
      setPrediction(res);
    }
  }, [initialRecord]);

  const handleAnalyze = () => {
    setIsAnalyzing(true);
    setTimeout(() => {
      const result = predictInsiderThreat({
        userId,
        loginFrequency,
        fileAccessCount,
        sensitiveFilesAccessed: sensitiveFiles,
        emailActivity,
        usbUsage,
        afterHoursActivity,
        failedLogins,
        dataTransferMB
      });
      setPrediction(result);
      setIsAnalyzing(false);
      if (onRecordPrediction) {
        onRecordPrediction(result);
      }
    }, 380);
  };

  const handleLoadPreset = (preset: 'u003' | 'u001' | 'u021' | 'departing') => {
    if (preset === 'u003') {
      setUserId('U003');
      setLoginFrequency(8);
      setFileAccessCount(42);
      setEmailActivity(17);
      setUsbUsage(true);
      setAfterHoursActivity(true);
      setSensitiveFiles(18);
      setFailedLogins(4);
      setDataTransferMB(4850);
    } else if (preset === 'u001') {
      setUserId('U001');
      setLoginFrequency(4);
      setFileAccessCount(14);
      setEmailActivity(9);
      setUsbUsage(false);
      setAfterHoursActivity(false);
      setSensitiveFiles(0);
      setFailedLogins(0);
      setDataTransferMB(120);
    } else if (preset === 'u021') {
      setUserId('U021');
      setLoginFrequency(7);
      setFileAccessCount(38);
      setEmailActivity(15);
      setUsbUsage(true);
      setAfterHoursActivity(false);
      setSensitiveFiles(9);
      setFailedLogins(2);
      setDataTransferMB(1890);
    } else if (preset === 'departing') {
      setUserId('User_1042');
      setLoginFrequency(12);
      setFileAccessCount(55);
      setEmailActivity(32);
      setUsbUsage(true);
      setAfterHoursActivity(true);
      setSensitiveFiles(24);
      setFailedLogins(5);
      setDataTransferMB(7200);
    }
  };

  // Helper for rendering ASCII-style block progress: █████████████████░░
  const renderAsciiProgressBar = (pct: number) => {
    const totalBlocks = 20;
    const filledBlocks = Math.round((pct / 100) * totalBlocks);
    const emptyBlocks = totalBlocks - filledBlocks;
    return '█'.repeat(filledBlocks) + '░'.repeat(emptyBlocks);
  };

  return (
    <div className="space-y-6">
      {/* Title & Introduction */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Threat Detection</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time interactive ML inference engine powered by Elastic Net & Random Forest
          </p>
        </div>

        {/* Quick presets */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-mono text-slate-400 mr-1 hidden sm:inline">
            Load Preset:
          </span>
          <button
            onClick={() => handleLoadPreset('u003')}
            className="px-2.5 py-1 text-[11px] font-mono rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 transition-colors cursor-pointer"
          >
            U003 (Threat)
          </button>
          <button
            onClick={() => handleLoadPreset('u021')}
            className="px-2.5 py-1 text-[11px] font-mono rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-colors cursor-pointer"
          >
            U021 (Medium)
          </button>
          <button
            onClick={() => handleLoadPreset('u001')}
            className="px-2.5 py-1 text-[11px] font-mono rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 transition-colors cursor-pointer"
          >
            U001 (Normal)
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Form: Enter User Activity (5 cols) */}
        <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-xl p-6 shadow-sm">
          <div className="border-b border-slate-800 pb-3 mb-5 flex items-center justify-between">
            <div>
              <h2 className="text-base font-semibold text-white">Enter User Activity</h2>
              <p className="text-xs text-slate-400">Configure endpoint telemetry signals for classification</p>
            </div>
            <span className="text-[11px] font-mono text-slate-500 uppercase">Input Vector</span>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleAnalyze();
            }}
            className="space-y-4 font-mono text-xs"
          >
            {/* User ID */}
            <div>
              <label className="block text-slate-300 mb-1 font-semibold">
                User ID
              </label>
              <input
                type="text"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                placeholder="e.g. U003"
                className="w-full px-3 py-2 bg-slate-950/80 border border-slate-800 rounded-lg text-slate-100 focus:outline-none focus:border-rose-500 font-bold"
              />
            </div>

            {/* Login Frequency & File Access */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-slate-300 font-semibold">Login Frequency</label>
                  <span className="text-rose-400 font-bold">{loginFrequency} / day</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="30"
                  value={loginFrequency}
                  onChange={(e) => setLoginFrequency(Number(e.target.value))}
                  className="w-full accent-rose-500 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-slate-300 font-semibold">File Access</label>
                  <span className="text-rose-400 font-bold">{fileAccessCount} files</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={fileAccessCount}
                  onChange={(e) => setFileAccessCount(Number(e.target.value))}
                  className="w-full accent-rose-500 cursor-pointer"
                />
              </div>
            </div>

            {/* Email Activity & Sensitive Files */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-slate-300 font-semibold">Email Activity</label>
                  <span className="text-rose-400 font-bold">{emailActivity} / day</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="60"
                  value={emailActivity}
                  onChange={(e) => setEmailActivity(Number(e.target.value))}
                  className="w-full accent-rose-500 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-slate-300 font-semibold">Sensitive Files</label>
                  <span className="text-rose-400 font-bold">{sensitiveFiles} files</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="40"
                  value={sensitiveFiles}
                  onChange={(e) => setSensitiveFiles(Number(e.target.value))}
                  className="w-full accent-rose-500 cursor-pointer"
                />
              </div>
            </div>

            {/* USB Usage & After-hours Activity Toggles as requested */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              {/* USB Usage [ Yes / No ] */}
              <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
                <span className="block text-slate-300 font-semibold mb-2">USB Usage</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setUsbUsage(true)}
                    className={`py-1.5 px-3 rounded text-center transition-all cursor-pointer ${
                      usbUsage
                        ? 'bg-rose-600 text-white font-bold shadow-xs'
                        : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Yes
                  </button>
                  <button
                    type="button"
                    onClick={() => setUsbUsage(false)}
                    className={`py-1.5 px-3 rounded text-center transition-all cursor-pointer ${
                      !usbUsage
                        ? 'bg-slate-800 text-white font-bold'
                        : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    No
                  </button>
                </div>
              </div>

              {/* After-hours Activity [ Yes / No ] */}
              <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
                <span className="block text-slate-300 font-semibold mb-2">After-hours Activity</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAfterHoursActivity(true)}
                    className={`py-1.5 px-3 rounded text-center transition-all cursor-pointer ${
                      afterHoursActivity
                        ? 'bg-amber-600 text-white font-bold shadow-xs'
                        : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Yes
                  </button>
                  <button
                    type="button"
                    onClick={() => setAfterHoursActivity(false)}
                    className={`py-1.5 px-3 rounded text-center transition-all cursor-pointer ${
                      !afterHoursActivity
                        ? 'bg-slate-800 text-white font-bold'
                        : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    No
                  </button>
                </div>
              </div>
            </div>

            {/* Extra Telemetry fields (Collapsible / Compact) */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Failed Logins</label>
                <input
                  type="number"
                  min="0"
                  max="15"
                  value={failedLogins}
                  onChange={(e) => setFailedLogins(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 bg-slate-950/70 border border-slate-800 rounded text-slate-200"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Data Transfer (MB)</label>
                <input
                  type="number"
                  min="10"
                  max="20000"
                  value={dataTransferMB}
                  onChange={(e) => setDataTransferMB(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 bg-slate-950/70 border border-slate-800 rounded text-slate-200"
                />
              </div>
            </div>

            {/* [ 🔍 ANALYZE ACTIVITY ] CTA button */}
            <button
              type="submit"
              disabled={isAnalyzing}
              className="w-full mt-4 py-3 px-4 bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-bold text-xs uppercase tracking-wider rounded-lg shadow-lg shadow-rose-950/60 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
            >
              {isAnalyzing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>RUNNING RANDOM FOREST ENSEMBLE...</span>
                </>
              ) : (
                <>
                  <Search className="w-4 h-4" />
                  <span>🔍 ANALYZE ACTIVITY</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right Output: PREDICTION RESULT as specified (7 cols) */}
        <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-xl p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="border-b border-slate-800 pb-3 mb-4 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase">
                  Inference Output
                </span>
                <h2 className="text-base font-semibold text-white">PREDICTION RESULT</h2>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Latency: 14ms
              </span>
            </div>

            {prediction ? (
              <div className="space-y-6">
                {/* Result Banner: 🔴 POTENTIAL THREAT */}
                <div
                  className={`p-4 rounded-xl border text-center transition-all ${
                    prediction.isThreat
                      ? 'bg-rose-500/10 border-rose-500/30'
                      : 'bg-emerald-500/10 border-emerald-500/30'
                  }`}
                >
                  <div className="text-2xl font-black font-mono tracking-tight flex items-center justify-center gap-2">
                    {prediction.isThreat ? (
                      <span className="text-rose-400 flex items-center gap-2">
                        <span>🔴</span> POTENTIAL THREAT
                      </span>
                    ) : (
                      <span className="text-emerald-400 flex items-center gap-2">
                        <span>🟢</span> NORMAL BEHAVIOR
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 font-mono mt-1">
                    Classification Target: {prediction.userId} · Confidence: {prediction.confidence}%
                  </p>
                </div>

                {/* Risk Probability & Gauge */}
                <div className="flex flex-col items-center justify-center py-2">
                  <RiskGauge probability={prediction.riskProbability} size={190} />

                  {/* Requested ASCII block progress indicator: █████████████████░░ */}
                  <div className="mt-3 text-center">
                    <div className="font-mono text-base tracking-widest text-rose-400 font-bold select-all">
                      {renderAsciiProgressBar(prediction.riskProbability)}
                    </div>
                    <div className="text-[10px] font-mono text-slate-500 mt-1">
                      Probability Scale: 0% [Normal] ────── 50% ────── 100% [Threat]
                    </div>
                  </div>
                </div>

                {/* Model Attribution as requested */}
                <div className="p-3.5 rounded-lg bg-slate-950/80 border border-slate-800 space-y-1.5 font-mono text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Model:</span>
                    <span className="text-slate-100 font-semibold">Random Forest (200 Trees)</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Feature Selection:</span>
                    <span className="text-rose-400 font-semibold">Elastic Net (L1 Regularized)</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Ensemble Agreement:</span>
                    <span className="text-slate-200">
                      {Math.round((prediction.riskProbability / 100) * 200)} / 200 Trees voted Threat
                    </span>
                  </div>
                </div>

                {/* Feature Attribution Drivers */}
                <div className="space-y-2">
                  <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 block font-semibold">
                    Key Explanatory Drivers (MDI Attribution):
                  </span>
                  <div className="space-y-1.5 text-xs font-mono">
                    {prediction.contributingFeatures.slice(0, 3).map((f, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between p-2 rounded bg-slate-950/50 border border-slate-800/80"
                      >
                        <span className="text-slate-300">{f.name}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-slate-400 text-[11px]">{f.value}</span>
                          <span
                            className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                              f.impact === 'critical'
                                ? 'bg-rose-500/20 text-rose-300'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            +{f.importance}%
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-64 flex flex-col items-center justify-center text-slate-500 text-xs">
                <span>Enter telemetry and click Analyze Activity</span>
              </div>
            )}
          </div>

          {/* Recommended Response */}
          {prediction && (
            <div className="pt-4 border-t border-slate-800 text-xs font-mono">
              <span className="text-slate-400 block text-[10px] uppercase font-bold mb-1">
                SOC Recommended Action:
              </span>
              <p
                className={`p-2.5 rounded-lg border text-[11px] font-sans ${
                  prediction.isThreat
                    ? 'bg-rose-950/30 border-rose-500/30 text-rose-200'
                    : 'bg-emerald-950/30 border-emerald-500/30 text-emerald-200'
                }`}
              >
                {prediction.recommendedAction}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
