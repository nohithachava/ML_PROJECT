import React from 'react';
import { Info, BookOpen, ShieldCheck, GraduationCap, CheckCircle2, Award } from 'lucide-react';

export function AboutView() {
  return (
    <div className="space-y-6 max-w-4xl font-mono text-xs">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2 font-sans">
            <span>About INSIDER GUARD</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Machine Learning Academic Defense Guide & Technical Architecture
          </p>
        </div>
        <div className="flex items-center gap-2 text-rose-400">
          <GraduationCap className="w-5 h-5" />
          <span>Major Project viva Defense Ready</span>
        </div>
      </div>

      {/* Abstract */}
      <div className="p-6 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3 font-sans">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Award className="w-4 h-4 text-amber-400" />
          <span>Project Abstract & Core Thesis</span>
        </h2>
        <p className="text-xs text-slate-300 leading-relaxed">
          <strong>INSIDER GUARD</strong> is an enterprise-grade AI-powered insider threat detection system engineered to address the twin challenges of <em>high multicollinearity</em> and <em>severe class imbalance</em> in enterprise activity logs. By unifying <strong>Elastic Net regularized feature selection</strong> with a <strong>Random Forest ensemble classifier (200 trees)</strong>, the system achieves a <strong>96.8% accuracy</strong> and <strong>93.3% F1-score</strong> on 1,250 benchmark activity instances.
        </p>
      </div>

      {/* Viva Talking Points */}
      <div className="p-6 rounded-xl bg-slate-900/90 border border-slate-800 space-y-4">
        <h2 className="text-sm font-bold text-white font-mono uppercase tracking-wider text-rose-400">
          🎯 Key Viva / Defense Questions & Answers
        </h2>

        <div className="space-y-3 text-slate-300 leading-relaxed font-sans">
          <div className="p-3.5 rounded-lg bg-slate-950/70 border border-slate-800">
            <strong className="text-rose-400 block font-mono text-xs mb-1">
              Q1: Why not use simple Lasso (L1) or Ridge (L2) regression alone?
            </strong>
            <p className="text-xs text-slate-300">
              When features are highly correlated (as in workplace logs where active hours and file reads move together), Lasso arbitrarily selects just one variable and drops the rest, losing synergistic signal. Ridge shrinks all weights but never produces a sparse model (cannot prune useless features). <strong>Elastic Net solves both</strong> by balancing L1 sparsity and L2 grouping through the convex combination penalty with &rho; = 0.50.
            </p>
          </div>

          <div className="p-3.5 rounded-lg bg-slate-950/70 border border-slate-800">
            <strong className="text-rose-400 block font-mono text-xs mb-1">
              Q2: How do you handle the 94:6 class imbalance without predicting only "Normal"?
            </strong>
            <p className="text-xs text-slate-300">
              We apply <code>class_weight='balanced'</code> within the Random Forest ensemble, which automatically adjusts sample weights inversely proportional to class frequencies: w_c = N / (2 &times; N_c). This heavily penalizes false negatives on minority threat instances, enabling <strong>92.5% Recall</strong> without excessive false alarms.
            </p>
          </div>

          <div className="p-3.5 rounded-lg bg-slate-950/70 border border-slate-800">
            <strong className="text-rose-400 block font-mono text-xs mb-1">
              Q3: Why use Random Forest instead of a Deep Neural Network?
            </strong>
            <p className="text-xs text-slate-300">
              Tabular behavioral logs benefit significantly more from tree ensembles than deep networks due to sharp decision boundaries and invariant feature scaling. Random Forest provides <strong>sub-15ms inference latency</strong>, requires zero GPU overhead in SOC runtime, and natively outputs Mean Decrease in Impurity (MDI) feature importances for legal/compliance explainability.
            </p>
          </div>
        </div>
      </div>

      {/* Academic Citations */}
      <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
        <h3 className="text-xs font-bold text-slate-200 uppercase font-mono tracking-wider">
          📚 Literature & Technical References
        </h3>
        <ul className="space-y-1.5 text-[11px] text-slate-400 font-mono list-disc pl-4">
          <li>Zou, H., &amp; Hastie, T. (2005). <em>Regularization and variable selection via the elastic net</em>. Journal of the Royal Statistical Society: Series B, 67(2), 301-320.</li>
          <li>Breiman, L. (2001). <em>Random forests</em>. Machine Learning, 45(1), 5-32.</li>
          <li>Glasser, J., &amp; Lindauer, B. (2013). <em>Bridging the gap: A pragmatic approach to generating insider threat data</em>. IEEE Security and Privacy Workshops (SPW).</li>
          <li>CERT Division, Software Engineering Institute (SEI), Carnegie Mellon University. <em>Insider Threat Dataset Testbed</em>.</li>
        </ul>
      </div>
    </div>
  );
}
