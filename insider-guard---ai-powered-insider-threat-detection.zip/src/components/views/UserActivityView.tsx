import React, { useState, useMemo } from 'react';
import { Search, Filter, ShieldAlert, ArrowRight, X, ExternalLink, Activity, HardDrive, Clock, Mail, CheckCircle2 } from 'lucide-react';
import { UserActivityRecord, RiskLevel } from '../../types';
import { ActivityBar } from '../shared/Charts';

interface UserActivityViewProps {
  records: UserActivityRecord[];
  onAnalyzeUser: (userId: string, record?: UserActivityRecord) => void;
}

export function UserActivityView({ records, onAnalyzeUser }: UserActivityViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [riskFilter, setRiskFilter] = useState<'All' | RiskLevel>('All');
  const [selectedUser, setSelectedUser] = useState<UserActivityRecord | null>(null);

  // Filtered records
  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      const matchSearch =
        r.userId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.department.toLowerCase().includes(searchQuery.toLowerCase());

      const matchRisk = riskFilter === 'All' || r.riskLevel === riskFilter;

      return matchSearch && matchRisk;
    });
  }, [records, searchQuery, riskFilter]);

  // Helper to categorize numeric values into display descriptors as requested
  const getDescriptor = (val: number, type: 'login' | 'file' | 'email') => {
    if (type === 'login') {
      return val >= 7 ? 'Abnormal' : 'Normal';
    }
    if (type === 'file') {
      return val >= 30 ? 'High' : val >= 20 ? 'Elevated' : 'Normal';
    }
    if (type === 'email') {
      return val >= 16 ? 'High' : val >= 12 ? 'Moderate' : 'Normal';
    }
    return 'Normal';
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>User Activity</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time behavioral telemetry monitoring across corporate endpoints
          </p>
        </div>

        {/* Search & Filter Toolbar */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Search User 🔍 */}
          <div className="relative min-w-[200px]">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search User (e.g. U003)..."
              className="w-full pl-9 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-rose-500 font-mono"
            />
          </div>

          {/* Filter ▼ */}
          <div className="relative">
            <select
              value={riskFilter}
              onChange={(e) => setRiskFilter(e.target.value as any)}
              className="appearance-none pl-3 pr-8 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-200 font-medium cursor-pointer focus:outline-none focus:border-rose-500 font-mono"
            >
              <option value="All">Filter: All Risks</option>
              <option value="High">🔴 High Risk</option>
              <option value="Medium">🟠 Medium Risk</option>
              <option value="Low">🟢 Low Risk</option>
            </select>
            <Filter className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Main Table: User | Login | File Access | Email | Risk */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-mono text-[11px] uppercase tracking-wider">
                <th className="py-3 px-4">User</th>
                <th className="py-3 px-4">Login</th>
                <th className="py-3 px-4">File Access</th>
                <th className="py-3 px-4">Email</th>
                <th className="py-3 px-4">USB Usage</th>
                <th className="py-3 px-4">After-Hours</th>
                <th className="py-3 px-4 text-center">Risk</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {filteredRecords.slice(0, 30).map((r) => {
                const loginDesc = getDescriptor(r.loginFrequency, 'login');
                const fileDesc = getDescriptor(r.fileAccessCount, 'file');
                const emailDesc = getDescriptor(r.emailActivity, 'email');

                const isHigh = r.riskLevel === 'High';
                const isMed = r.riskLevel === 'Medium';

                return (
                  <tr
                    key={r.id}
                    onClick={() => setSelectedUser(r)}
                    className="hover:bg-slate-800/50 transition-colors cursor-pointer group"
                  >
                    {/* User */}
                    <td className="py-3 px-4 font-bold text-slate-200 group-hover:text-rose-400 transition-colors">
                      <div className="flex items-center gap-2">
                        <span>{r.userId}</span>
                        <span className="text-[10px] text-slate-500 font-normal font-sans hidden sm:inline">
                          ({r.role})
                        </span>
                      </div>
                    </td>

                    {/* Login */}
                    <td className="py-3 px-4">
                      <span
                        className={
                          loginDesc === 'Abnormal'
                            ? 'text-rose-400 font-semibold'
                            : 'text-slate-300'
                        }
                      >
                        {loginDesc}
                      </span>
                      <span className="text-slate-500 text-[10px] ml-1">({r.loginFrequency}/d)</span>
                    </td>

                    {/* File Access */}
                    <td className="py-3 px-4">
                      <span
                        className={
                          fileDesc === 'High'
                            ? 'text-rose-400 font-semibold'
                            : fileDesc === 'Elevated'
                            ? 'text-amber-400'
                            : 'text-slate-300'
                        }
                      >
                        {fileDesc}
                      </span>
                      <span className="text-slate-500 text-[10px] ml-1">({r.fileAccessCount})</span>
                    </td>

                    {/* Email */}
                    <td className="py-3 px-4">
                      <span
                        className={
                          emailDesc === 'High'
                            ? 'text-rose-400 font-semibold'
                            : 'text-slate-300'
                        }
                      >
                        {emailDesc}
                      </span>
                      <span className="text-slate-500 text-[10px] ml-1">({r.emailActivity}/d)</span>
                    </td>

                    {/* USB */}
                    <td className="py-3 px-4">
                      {r.usbUsage ? (
                        <span className="text-rose-400 font-semibold">Yes</span>
                      ) : (
                        <span className="text-slate-400">No</span>
                      )}
                    </td>

                    {/* After Hours */}
                    <td className="py-3 px-4">
                      {r.afterHoursActivity ? (
                        <span className="text-amber-400 font-semibold">Yes</span>
                      ) : (
                        <span className="text-slate-400">No</span>
                      )}
                    </td>

                    {/* Risk Indicator matching format: 🟢 Low / 🟠 Med / 🔴 High */}
                    <td className="py-3 px-4 text-center">
                      {isHigh && (
                        <span className="inline-flex items-center gap-1 text-rose-400 font-bold">
                          <span>🔴</span>
                          <span>High</span>
                        </span>
                      )}
                      {isMed && (
                        <span className="inline-flex items-center gap-1 text-amber-400 font-bold">
                          <span>🟠</span>
                          <span>Med</span>
                        </span>
                      )}
                      {!isHigh && !isMed && (
                        <span className="inline-flex items-center gap-1 text-emerald-400 font-bold">
                          <span>🟢</span>
                          <span>Low</span>
                        </span>
                      )}
                    </td>

                    {/* Action */}
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedUser(r);
                        }}
                        className="px-2.5 py-1 text-[11px] bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 transition-colors"
                      >
                        View Details
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Table footer */}
        <div className="p-3 bg-slate-950/40 border-t border-slate-800 text-xs text-slate-400 font-mono flex items-center justify-between">
          <span>
            Showing {Math.min(30, filteredRecords.length)} of {filteredRecords.length} workforce users
          </span>
          <span className="text-[11px] text-slate-500">Click any row to open User Details</span>
        </div>
      </div>

      {/* User Details Modal / Drawer as specified:
          User Details
          User U003
          Risk Level: 🔴 HIGH
          Activity Summary
          ────────────────────
          Login Activity ██████████
          File Access    ███████████████
          Email Activity ████████
          USB Activity   █████████████
          [ Analyze User ]
      */}
      {selectedUser && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-150">
            {/* Close button */}
            <button
              onClick={() => setSelectedUser(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Title */}
            <div className="mb-4">
              <div className="text-xs uppercase font-mono tracking-widest text-slate-400 mb-1">
                User Details
              </div>
              <h2 className="text-2xl font-bold font-mono text-white flex items-center gap-2">
                <span>User {selectedUser.userId}</span>
              </h2>
              <div className="text-xs text-slate-400 mt-1 font-mono">
                {selectedUser.role} · {selectedUser.department} Department
              </div>
            </div>

            {/* Risk Level Badge */}
            <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800 mb-6 flex items-center justify-between">
              <span className="text-xs text-slate-300 font-medium">Risk Level:</span>
              <span className="font-mono font-bold text-sm flex items-center gap-1.5">
                {selectedUser.riskLevel === 'High' && (
                  <span className="text-rose-400 flex items-center gap-1">
                    <span>🔴</span> HIGH (Threat Probability: {(selectedUser.threatScore * 100).toFixed(1)}%)
                  </span>
                )}
                {selectedUser.riskLevel === 'Medium' && (
                  <span className="text-amber-400 flex items-center gap-1">
                    <span>🟠</span> MEDIUM (Threat Probability: {(selectedUser.threatScore * 100).toFixed(1)}%)
                  </span>
                )}
                {selectedUser.riskLevel === 'Low' && (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <span>🟢</span> LOW (Threat Probability: {(selectedUser.threatScore * 100).toFixed(1)}%)
                  </span>
                )}
              </span>
            </div>

            {/* Activity Summary with Visual Bars as requested */}
            <div className="mb-6 space-y-4">
              <div className="border-b border-slate-800 pb-2">
                <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold">
                  Activity Summary
                </h3>
              </div>

              <div className="space-y-3.5 font-mono">
                {/* Login Activity */}
                <ActivityBar
                  label="Login Activity"
                  value={selectedUser.loginFrequency}
                  max={15}
                  color={selectedUser.loginFrequency >= 7 ? 'bg-rose-500' : 'bg-emerald-500'}
                  displayValue={`${selectedUser.loginFrequency} logins/day`}
                />

                {/* File Access */}
                <ActivityBar
                  label="File Access"
                  value={selectedUser.fileAccessCount}
                  max={60}
                  color={selectedUser.fileAccessCount >= 30 ? 'bg-rose-500' : selectedUser.fileAccessCount >= 20 ? 'bg-amber-500' : 'bg-emerald-500'}
                  displayValue={`${selectedUser.fileAccessCount} files`}
                />

                {/* Email Activity */}
                <ActivityBar
                  label="Email Activity"
                  value={selectedUser.emailActivity}
                  max={50}
                  color={selectedUser.emailActivity >= 20 ? 'bg-rose-500' : 'bg-emerald-500'}
                  displayValue={`${selectedUser.emailActivity} emails/day`}
                />

                {/* USB Activity */}
                <ActivityBar
                  label="USB Activity"
                  value={selectedUser.usbUsage ? 100 : 0}
                  max={100}
                  color={selectedUser.usbUsage ? 'bg-rose-500' : 'bg-slate-700'}
                  displayValue={selectedUser.usbUsage ? '█████████████ (Attached)' : 'None (Compliant)'}
                />
              </div>
            </div>

            {/* Additional Telemetry Context */}
            <div className="grid grid-cols-2 gap-2 text-xs font-mono p-3 bg-slate-950/60 rounded-lg border border-slate-800/80 mb-6">
              <div>
                <span className="text-slate-400 block text-[10px]">After-Hours Work:</span>
                <span className={selectedUser.afterHoursActivity ? 'text-amber-400 font-bold' : 'text-slate-300'}>
                  {selectedUser.afterHoursActivity ? 'Yes (Detected)' : 'No (Standard)'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Failed Logins:</span>
                <span className={selectedUser.failedLogins > 1 ? 'text-rose-400 font-bold' : 'text-slate-300'}>
                  {selectedUser.failedLogins} attempts
                </span>
              </div>
            </div>

            {/* [ Analyze User ] CTA button */}
            <button
              onClick={() => {
                const user = selectedUser;
                setSelectedUser(null);
                onAnalyzeUser(user.userId, user);
              }}
              className="w-full py-3 px-4 bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-bold text-xs uppercase tracking-wider rounded-lg shadow-lg shadow-rose-950/60 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Analyze User with Random Forest</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
