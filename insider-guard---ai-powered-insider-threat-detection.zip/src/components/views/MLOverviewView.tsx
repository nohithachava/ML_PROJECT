import { BrainCircuit, Binary, Trees, LineChart, ShieldCheck, ArrowRight, CheckCircle2, Cpu } from 'lucide-react';
import { NavTab } from '../Sidebar';

interface MLOverviewViewProps {
  onNavigate: (tab: NavTab) => void;
}

export function MLOverviewView({ onNavigate }: MLOverviewViewProps) {
  const steps = [
    {
      num: '01',
      title: 'Multimodal Telemetry Ingestion',
      desc: '14 continuous and categorical features collected from endpoint sensors, directory services, and mail gateways.',
      formula: 'X ∈ ℝ^(1250 × 14)'
    },
    {
      num: '02',
      title: 'Elastic Net Regularization & Feature Selection',
      desc: 'Simultaneous L1 (Lasso) and L2 (Ridge) penalty to eliminate non-informative noise and overcome high multicollinearity.',
      formula: 'min_w [ (1/2n)||y - Xw||² + λ(ρ||w||₁ + ((1-ρ)/2)||w||₂²) ]'
    },
    {
      num: '03',
      title: 'Bagging & Random Forest Classifier',
      desc: 'Ensemble of 200 de-correlated decision trees with balanced class weighting to overcome the 94:6 normal-to-threat imbalance.',
      formula: 'ŷ = (1/B) Σ T_b(X_selected), B=200'
    },
    {
      num: '04',
      title: 'Calibrated Threat Probability Scoring',
      desc: 'Continuous probability estimation (0.0% to 100.0%) feeding automated SOC alert triage and incident mitigation.',
      formula: 'P(Threat | x) ≥ 0.50 ⟹ Alert Trigger'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Machine Learning Architecture</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Hybrid Pipeline: Elastic Net Feature Selection + Random Forest Ensemble Classifier
          </p>
        </div>
        <div className="flex items-center gap-2 font-mono text-xs text-emerald-400">
          <ShieldCheck className="w-4 h-4" />
          <span>F1 Score: 93.3% · ROC-AUC: 0.978</span>
        </div>
      </div>

      {/* Why This Pipeline Section */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 shadow-sm">
        <h2 className="text-base font-semibold text-white mb-2">
          Why Combine Elastic Net & Random Forest?
        </h2>
        <p className="text-xs text-slate-300 leading-relaxed max-w-4xl">
          Insider threat detection presents two foundational challenges in applied machine learning:
          <strong> extreme class imbalance</strong> (only ~5.6% of workplace activities are malicious) and
          <strong> high multicollinearity</strong> across telemetry logs (e.g. active hours, file reads, and session auths move in tandem).
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-rose-400 font-mono text-xs font-bold uppercase">
              <Binary className="w-4 h-4" />
              <span>Phase 1: Elastic Net (Sparse Feature Selection)</span>
            </div>
            <p className="text-xs text-slate-400 leading-normal">
              Standard Lasso (L1) fails with collinear features by arbitrarily picking one feature and dropping the others. Ridge (L2) retains all features without sparsity. Elastic Net combines both with an L1 ratio &rho; = 0.50, grouping correlated threat signals and shrinking 6 noisy variables to strict zero.
            </p>
            <div className="pt-2">
              <button
                onClick={() => onNavigate('elastic_net')}
                className="text-xs font-mono text-rose-400 hover:text-rose-300 flex items-center gap-1 cursor-pointer"
              >
                <span>Inspect Elastic Net Weights</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs font-bold uppercase">
              <Trees className="w-4 h-4" />
              <span>Phase 2: Random Forest (Ensemble Classifier)</span>
            </div>
            <p className="text-xs text-slate-400 leading-normal">
              Feeding regularized features into 200 bagging decision trees captures complex non-linear interactions (e.g., USB attached AND after-hours logons) without overfitting. Balanced class weights penalize minority false negatives, achieving 92.5% Recall.
            </p>
            <div className="pt-2">
              <button
                onClick={() => onNavigate('random_forest')}
                className="text-xs font-mono text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer"
              >
                <span>Inspect 200-Tree Forest</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 4-Step Pipeline Flow */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
          End-to-End Pipeline Execution Flow
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {steps.map((st, i) => (
            <div
              key={i}
              className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 flex flex-col justify-between"
            >
              <div>
                <span className="text-xl font-mono font-black text-rose-500/40 block mb-2">
                  {st.num}
                </span>
                <h4 className="text-xs font-bold text-white mb-1.5">{st.title}</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
                  {st.desc}
                </p>
              </div>
              <div className="p-2 rounded bg-slate-950 border border-slate-800/80 font-mono text-[10px] text-slate-400 truncate">
                {st.formula}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Navigation Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
        <button
          onClick={() => onNavigate('elastic_net')}
          className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 text-left transition-all cursor-pointer group"
        >
          <span className="text-[10px] text-rose-400 uppercase block mb-1">Detailed View</span>
          <span className="text-sm font-bold text-white group-hover:text-rose-400 flex items-center justify-between">
            <span>🔬 Elastic Net Selection</span>
            <ArrowRight className="w-4 h-4" />
          </span>
          <p className="text-[11px] font-sans text-slate-400 mt-1">
            Explore shrinkage paths, L1 ratio slider, and zeroed features.
          </p>
        </button>

        <button
          onClick={() => onNavigate('random_forest')}
          className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 text-left transition-all cursor-pointer group"
        >
          <span className="text-[10px] text-emerald-400 uppercase block mb-1">Detailed View</span>
          <span className="text-sm font-bold text-white group-hover:text-emerald-400 flex items-center justify-between">
            <span>🌲 Random Forest Specs</span>
            <ArrowRight className="w-4 h-4" />
          </span>
          <p className="text-[11px] font-sans text-slate-400 mt-1">
            Tree voting, Gini impurity criterion, and feature importance.
          </p>
        </button>

        <button
          onClick={() => onNavigate('model_evaluation')}
          className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 text-left transition-all cursor-pointer group"
        >
          <span className="text-[10px] text-cyan-400 uppercase block mb-1">Detailed View</span>
          <span className="text-sm font-bold text-white group-hover:text-cyan-400 flex items-center justify-between">
            <span>📈 Model Evaluation</span>
            <ArrowRight className="w-4 h-4" />
          </span>
          <p className="text-[11px] font-sans text-slate-400 mt-1">
            Confusion matrix, ROC-AUC curve, and benchmark comparisons.
          </p>
        </button>
      </div>
    </div>
  );
}
