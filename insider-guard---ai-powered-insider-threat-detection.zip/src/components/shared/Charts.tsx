import React from 'react';

// Reusable SVG Donut Chart
export function DonutChart({
  normalPercent = 94,
  threatPercent = 6,
  size = 200,
  strokeWidth = 24,
  centerTitle = '94%',
  centerSubtitle = 'NORMAL'
}: {
  normalPercent?: number;
  threatPercent?: number;
  size?: number;
  strokeWidth?: number;
  centerTitle?: string;
  centerSubtitle?: string;
}) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const normalOffset = circumference - (circumference * normalPercent) / 100;
  const threatOffset = circumference - (circumference * threatPercent) / 100;

  return (
    <div className="relative inline-flex items-center justify-center">
      <svg width={size} height={size} className="-rotate-90">
        {/* Background track */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="transparent"
          stroke="#1e293b"
          strokeWidth={strokeWidth}
        />
        {/* Normal segment (Emerald/Cyan) */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="transparent"
          stroke="#10b981"
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={normalOffset}
          strokeLinecap="round"
          className="transition-all duration-1000 ease-out"
        />
        {/* Threat segment (Rose/Red) */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="transparent"
          stroke="#f43f5e"
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={threatOffset}
          strokeLinecap="round"
          className="transition-all duration-1000 ease-out"
          style={{
            transformOrigin: 'center',
            transform: `rotate(${(normalPercent / 100) * 360}deg)`
          }}
        />
      </svg>
      <div className="absolute flex flex-col items-center justify-center text-center">
        <span className="font-mono text-2xl font-bold text-slate-100 tracking-tight">{centerTitle}</span>
        <span className="text-xs uppercase tracking-wider text-emerald-400 font-semibold">{centerSubtitle}</span>
      </div>
    </div>
  );
}

// Threat Activity Over Time Trend Line/Area Chart
export function ThreatTrendGraph({
  data = [
    { day: 'Mon', threats: 8, normal: 165 },
    { day: 'Tue', threats: 14, normal: 172 },
    { day: 'Wed', threats: 9, normal: 180 },
    { day: 'Thu', threats: 18, normal: 160 },
    { day: 'Fri', threats: 12, normal: 175 },
    { day: 'Sat', threats: 5, normal: 85 },
    { day: 'Sun', threats: 4, normal: 65 }
  ],
  height = 180
}: {
  data?: { day: string; threats: number; normal: number }[];
  height?: number;
}) {
  const [hoveredIdx, setHoveredIdx] = React.useState<number | null>(null);
  const maxThreat = Math.max(...data.map(d => d.threats), 20);
  const width = 500;
  const paddingX = 40;
  const paddingY = 25;
  const usableWidth = width - paddingX * 2;
  const usableHeight = height - paddingY * 2;

  const points = data.map((d, i) => {
    const x = paddingX + (i / (data.length - 1)) * usableWidth;
    const y = height - paddingY - (d.threats / maxThreat) * usableHeight;
    return { x, y, ...d };
  });

  const pathD = points.reduce((acc, curr, i, arr) => {
    if (i === 0) return `M ${curr.x} ${curr.y}`;
    const prev = arr[i - 1];
    const cp1x = prev.x + (curr.x - prev.x) / 2;
    const cp1y = prev.y;
    const cp2x = prev.x + (curr.x - prev.x) / 2;
    const cp2y = curr.y;
    return `${acc} C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${curr.x} ${curr.y}`;
  }, '');

  const areaD = `${pathD} L ${points[points.length - 1].x} ${height - paddingY} L ${points[0].x} ${height - paddingY} Z`;

  return (
    <div className="w-full relative">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible">
        <defs>
          <linearGradient id="threatAreaGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#f43f5e" stopOpacity="0.0" />
          </linearGradient>
        </defs>

        {/* Horizontal gridlines */}
        {[0, 0.5, 1].map((pct, i) => {
          const y = height - paddingY - pct * usableHeight;
          return (
            <g key={i}>
              <line x1={paddingX} y1={y} x2={width - paddingX} y2={y} stroke="#334155" strokeDasharray="3 3" strokeWidth="1" />
              <text x={paddingX - 8} y={y + 3} textAnchor="end" fill="#64748b" className="text-[10px] font-mono">
                {Math.round(pct * maxThreat)}
              </text>
            </g>
          );
        })}

        {/* Filled Area */}
        <path d={areaD} fill="url(#threatAreaGrad)" />

        {/* Curved Path */}
        <path d={pathD} fill="none" stroke="#f43f5e" strokeWidth="2.5" strokeLinecap="round" />

        {/* Points */}
        {points.map((pt, i) => (
          <g key={i} className="cursor-pointer" onMouseEnter={() => setHoveredIdx(i)} onMouseLeave={() => setHoveredIdx(null)}>
            <circle cx={pt.x} cy={pt.y} r={hoveredIdx === i ? 6 : 4} fill="#0f172a" stroke="#f43f5e" strokeWidth="2" className="transition-all" />
            <text x={pt.x} y={height - 8} textAnchor="middle" fill="#94a3b8" className="text-[11px] font-mono">
              {pt.day}
            </text>
          </g>
        ))}
      </svg>

      {hoveredIdx !== null && (
        <div
          className="absolute bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-xs shadow-xl pointer-events-none transform -translate-x-1/2 -translate-y-12 z-20"
          style={{
            left: `${(points[hoveredIdx].x / width) * 100}%`,
            top: `${(points[hoveredIdx].y / height) * 100}%`
          }}
        >
          <div className="font-semibold text-rose-400">{points[hoveredIdx].threats} Threats Detected</div>
          <div className="text-slate-400 text-[10px] font-mono">{points[hoveredIdx].normal} Normal Activities</div>
        </div>
      )}
    </div>
  );
}

// Circular Risk Gauge for Threat Detection
export function RiskGauge({
  probability = 87.4,
  size = 180
}: {
  probability: number;
  size?: number;
}) {
  const stroke = 16;
  const radius = (size - stroke) / 2;
  const circumference = Math.PI * radius; // Half circle (180 deg)
  const offset = circumference - (circumference * Math.min(100, Math.max(0, probability))) / 100;

  const getColor = (val: number) => {
    if (val >= 75) return '#f43f5e'; // rose-500
    if (val >= 40) return '#f59e0b'; // amber-500
    return '#10b981'; // emerald-500
  };

  const color = getColor(probability);

  return (
    <div className="flex flex-col items-center justify-center">
      <div className="relative inline-flex items-center justify-center">
        <svg width={size} height={size * 0.65} viewBox={`0 0 ${size} ${size * 0.65}`}>
          {/* Background arc */}
          <path
            d={`M ${stroke / 2} ${size / 2} A ${radius} ${radius} 0 0 1 ${size - stroke / 2} ${size / 2}`}
            fill="none"
            stroke="#1e293b"
            strokeWidth={stroke}
            strokeLinecap="round"
          />
          {/* Value arc */}
          <path
            d={`M ${stroke / 2} ${size / 2} A ${radius} ${radius} 0 0 1 ${size - stroke / 2} ${size / 2}`}
            fill="none"
            stroke={color}
            strokeWidth={stroke}
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-out"
          />
        </svg>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/4 text-center">
          <div className="text-3xl font-extrabold font-mono tracking-tight" style={{ color }}>
            {probability.toFixed(1)}%
          </div>
          <div className="text-[11px] uppercase tracking-wider text-slate-400 font-medium">Risk Probability</div>
        </div>
      </div>
    </div>
  );
}

// Activity Progress Meter for User details and forms
export function ActivityBar({
  label,
  value,
  max = 100,
  color = 'bg-rose-500',
  displayValue
}: {
  label: string;
  value: number;
  max?: number;
  color?: string;
  displayValue?: string;
}) {
  const percent = Math.min(100, Math.max(0, (value / max) * 100));
  return (
    <div className="space-y-1.5">
      <div className="flex justify-between text-xs">
        <span className="text-slate-300 font-medium">{label}</span>
        <span className="font-mono text-slate-400">{displayValue ?? `${value}`}</span>
      </div>
      <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
        <div
          className={`h-full ${color} rounded-full transition-all duration-700 ease-out`}
          style={{ width: `${percent}%` }}
        />
      </div>
    </div>
  );
}
