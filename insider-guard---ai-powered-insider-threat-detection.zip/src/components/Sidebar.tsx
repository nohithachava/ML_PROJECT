import React from 'react';
import {
  Shield,
  LayoutDashboard,
  Users,
  AlertTriangle,
  Bell,
  BarChart3,
  BrainCircuit,
  Binary,
  Trees,
  LineChart,
  Radio,
  RefreshCw,
  History,
  FileSpreadsheet,
  FileText,
  Settings,
  Info,
  LogOut,
  X
} from 'lucide-react';

export type NavTab =
  | 'dashboard'
  | 'user_activity'
  | 'threat_detection'
  | 'alerts'
  | 'analytics'
  | 'ml_overview'
  | 'elastic_net'
  | 'random_forest'
  | 'model_evaluation'
  | 'monitoring'
  | 'retraining'
  | 'prediction_history'
  | 'raw_dataset'
  | 'reports'
  | 'settings'
  | 'about';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onLogout: () => void;
  activeAlertCount?: number;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
}

export function Sidebar({
  currentTab,
  onSelectTab,
  onLogout,
  activeAlertCount = 5,
  isOpenMobile = false,
  onCloseMobile
}: SidebarProps) {
  const navItems: {
    section?: string;
    items: {
      id: NavTab;
      label: string;
      icon: React.ComponentType<{ className?: string }>;
      badge?: string | number;
    }[];
  }[] = [
    {
      items: [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'user_activity', label: 'User Activity', icon: Users },
        { id: 'threat_detection', label: 'Threat Detection', icon: AlertTriangle },
        { id: 'alerts', label: 'Alerts', icon: Bell, badge: activeAlertCount },
        { id: 'analytics', label: 'Analytics', icon: BarChart3 }
      ]
    },
    {
      section: 'MACHINE LEARNING',
      items: [
        { id: 'ml_overview', label: 'ML Overview', icon: BrainCircuit },
        { id: 'elastic_net', label: 'Elastic Net', icon: Binary },
        { id: 'random_forest', label: 'Random Forest', icon: Trees },
        { id: 'model_evaluation', label: 'Model Evaluation', icon: LineChart }
      ]
    },
    {
      section: 'MLOps',
      items: [
        { id: 'monitoring', label: 'Monitoring', icon: Radio },
        { id: 'retraining', label: 'Retraining', icon: RefreshCw },
        { id: 'prediction_history', label: 'Prediction History', icon: History }
      ]
    },
    {
      section: 'DATA & SYSTEM',
      items: [
        { id: 'raw_dataset', label: 'Raw Dataset', icon: FileSpreadsheet },
        { id: 'reports', label: 'Reports', icon: FileText },
        { id: 'settings', label: 'Settings', icon: Settings },
        { id: 'about', label: 'About', icon: Info }
      ]
    }
  ];

  return (
    <>
      {/* Mobile overlay */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-40 lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-slate-950 border-r border-slate-800/80 flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Lockup */}
        <div className="h-16 px-5 border-b border-slate-800/80 flex items-center justify-between">
          <div
            className="flex items-center gap-3 cursor-pointer group"
            onClick={() => onSelectTab('dashboard')}
          >
            <div className="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-500 group-hover:bg-rose-500/20 transition-colors">
              <Shield className="w-4 h-4 stroke-[2.2]" />
            </div>
            <div>
              <span className="font-bold tracking-tight text-white text-base leading-none block">
                INSIDER GUARD
              </span>
              <span className="text-[10px] text-slate-400 font-mono tracking-wider uppercase block mt-1">
                ML Threat SOC
              </span>
            </div>
          </div>
          {onCloseMobile && (
            <button
              onClick={onCloseMobile}
              className="lg:hidden p-1.5 text-slate-400 hover:text-white rounded-md"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6 scrollbar-thin scrollbar-thumb-slate-800">
          {navItems.map((group, gIdx) => (
            <div key={gIdx} className="space-y-1">
              {group.section && (
                <div className="px-3 pb-1 pt-2 text-[10px] font-mono tracking-widest text-slate-400 uppercase flex items-center gap-2">
                  <span>{group.section}</span>
                  <div className="h-px bg-slate-800/60 flex-1"></div>
                </div>
              )}
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSelectTab(item.id);
                      if (onCloseMobile) onCloseMobile();
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all group cursor-pointer ${
                      isActive
                        ? 'bg-rose-600/15 text-rose-400 border border-rose-500/30 font-semibold shadow-xs'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/80 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon
                        className={`w-4 h-4 transition-colors ${
                          isActive
                            ? 'text-rose-400'
                            : 'text-slate-400 group-hover:text-slate-200'
                        }`}
                      />
                      <span>{item.label}</span>
                    </div>

                    {item.badge !== undefined && (
                      <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>

        {/* User / Logout Footer */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-950">
          <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800/80 mb-2 flex items-center justify-between">
            <div className="flex items-center gap-2.5 overflow-hidden">
              <div className="w-7 h-7 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center font-mono text-xs font-bold shrink-0">
                SA
              </div>
              <div className="truncate">
                <div className="text-xs font-medium text-slate-200 truncate">
                  Security Analyst
                </div>
                <div className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Online · RF Node
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors cursor-pointer border border-slate-800/60"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </aside>
    </>
  );
}
