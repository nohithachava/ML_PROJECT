import React, { useState } from 'react';
import { LoginPage } from './components/LoginPage';
import { Sidebar, NavTab } from './components/Sidebar';
import { Header } from './components/Header';
import { DashboardView } from './components/views/DashboardView';
import { UserActivityView } from './components/views/UserActivityView';
import { ThreatDetectionView } from './components/views/ThreatDetectionView';
import { AlertsView } from './components/views/AlertsView';
import { AnalyticsView } from './components/views/AnalyticsView';
import { MLOverviewView } from './components/views/MLOverviewView';
import { ElasticNetView } from './components/views/ElasticNetView';
import { RandomForestView } from './components/views/RandomForestView';
import { ModelEvaluationView } from './components/views/ModelEvaluationView';
import { MonitoringView } from './components/views/MonitoringView';
import { RetrainingView } from './components/views/RetrainingView';
import { PredictionHistoryView } from './components/views/PredictionHistoryView';
import { RawDatasetView } from './components/views/RawDatasetView';
import { ReportsView } from './components/views/ReportsView';
import { SettingsView } from './components/views/SettingsView';
import { AboutView } from './components/views/AboutView';
import { initialDataset, initialAlerts, initialPredictionHistory, generateDatasetCsv } from './data/dataset';
import { SecurityAlert, UserActivityRecord, PredictionResult, PredictionHistoryEntry } from './types';

export default function App() {
  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true);
  const [currentUser, setCurrentUser] = useState<string>('Security Analyst');

  // Navigation state
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  // Core application data states
  const [dataset, setDataset] = useState<UserActivityRecord[]>(initialDataset);
  const [alerts, setAlerts] = useState<SecurityAlert[]>(initialAlerts);
  const [history, setHistory] = useState<PredictionHistoryEntry[]>(initialPredictionHistory);

  // Cross-view interaction parameters
  const [analyzeTargetUserId, setAnalyzeTargetUserId] = useState<string>('U003');
  const [analyzeTargetRecord, setAnalyzeTargetRecord] = useState<UserActivityRecord | undefined>(undefined);

  // Active alert count for badge
  const activeAlertCount = alerts.filter(a => a.status !== 'Resolved').length;

  // Handle Login
  const handleLogin = (username: string) => {
    setCurrentUser(username.includes('@') ? username.split('@')[0] : username);
    setIsAuthenticated(true);
    setCurrentTab('dashboard');
  };

  // Handle Logout
  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  // Jump from User Activity or Alerts directly into Threat Detection
  const handleAnalyzeUser = (userId: string, record?: UserActivityRecord) => {
    setAnalyzeTargetUserId(userId);
    if (record) {
      setAnalyzeTargetRecord(record);
    } else {
      const match = dataset.find(r => r.userId.toLowerCase() === userId.toLowerCase());
      setAnalyzeTargetRecord(match);
    }
    setCurrentTab('threat_detection');
  };

  // Record live prediction into Prediction History
  const handleRecordPrediction = (result: PredictionResult) => {
    const newEntry: PredictionHistoryEntry = {
      id: `PRED-${Math.floor(1000 + Math.random() * 9000)}`,
      date: '28 Sep',
      time: '14:25',
      userId: result.userId,
      prediction: result.isThreat ? 'Threat' : 'Normal',
      probability: Number(result.riskProbability.toFixed(1)),
      riskLevel: result.riskLevel,
      model: 'Random Forest + Elastic Net',
      status: result.riskLevel === 'Low' ? 'Resolved' : 'Active',
      activitySnapshot: {
        logins: 8,
        files: 42,
        emails: 17,
        usb: true,
        afterHours: true
      }
    };
    setHistory(prev => [newEntry, ...prev]);
  };

  // Update Alert status
  const handleUpdateAlertStatus = (alertId: string, newStatus: 'Active' | 'Investigating' | 'Resolved') => {
    setAlerts(prev => prev.map(a => a.id === alertId ? { ...a, status: newStatus } : a));
  };

  // Global Quick Download of the 1,250 records raw CSV
  const handleDownloadDataset = () => {
    const csvContent = generateDatasetCsv(dataset);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `insider_activity_dataset_1250_records.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // If not logged in, render the clean login screen as specified
  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex font-sans antialiased selection:bg-rose-500/30 selection:text-rose-200">
      {/* Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onLogout={handleLogout}
        activeAlertCount={activeAlertCount}
        isOpenMobile={isMobileMenuOpen}
        onCloseMobile={() => setIsMobileMenuOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 lg:pl-64">
        {/* Top Header */}
        <Header
          currentTab={currentTab}
          onOpenMobile={() => setIsMobileMenuOpen(true)}
          onQuickNavigate={setCurrentTab}
          onDownloadDataset={handleDownloadDataset}
        />

        {/* Dynamic View Container */}
        <main className="flex-1 p-4 md:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {currentTab === 'dashboard' && (
            <DashboardView
              alerts={alerts}
              onNavigate={setCurrentTab}
              onSelectAlert={(alert) => {
                setCurrentTab('alerts');
              }}
              onAnalyzeUser={handleAnalyzeUser}
            />
          )}

          {currentTab === 'user_activity' && (
            <UserActivityView
              records={dataset}
              onAnalyzeUser={handleAnalyzeUser}
            />
          )}

          {currentTab === 'threat_detection' && (
            <ThreatDetectionView
              initialUserId={analyzeTargetUserId}
              initialRecord={analyzeTargetRecord}
              onRecordPrediction={handleRecordPrediction}
            />
          )}

          {currentTab === 'alerts' && (
            <AlertsView
              alerts={alerts}
              onUpdateAlertStatus={handleUpdateAlertStatus}
              onAnalyzeUser={handleAnalyzeUser}
            />
          )}

          {currentTab === 'analytics' && (
            <AnalyticsView />
          )}

          {currentTab === 'ml_overview' && (
            <MLOverviewView onNavigate={setCurrentTab} />
          )}

          {currentTab === 'elastic_net' && (
            <ElasticNetView />
          )}

          {currentTab === 'random_forest' && (
            <RandomForestView />
          )}

          {currentTab === 'model_evaluation' && (
            <ModelEvaluationView />
          )}

          {currentTab === 'monitoring' && (
            <MonitoringView />
          )}

          {currentTab === 'retraining' && (
            <RetrainingView />
          )}

          {currentTab === 'prediction_history' && (
            <PredictionHistoryView
              history={history}
              onAnalyzeUser={handleAnalyzeUser}
            />
          )}

          {currentTab === 'raw_dataset' && (
            <RawDatasetView records={dataset} />
          )}

          {currentTab === 'reports' && (
            <ReportsView />
          )}

          {currentTab === 'settings' && (
            <SettingsView />
          )}

          {currentTab === 'about' && (
            <AboutView />
          )}
        </main>
      </div>
    </div>
  );
}
