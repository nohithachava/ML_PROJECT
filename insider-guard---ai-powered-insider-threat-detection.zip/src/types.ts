export type RiskLevel = 'Low' | 'Medium' | 'High';
export type ThreatCategory = 'None' | 'Data Exfiltration' | 'Privilege Escalation' | 'Unauthorized Access' | 'Intellectual Property Theft';
export type Department = 'Engineering' | 'Finance' | 'IT' | 'Sales' | 'Human Resources';

export interface UserActivityRecord {
  id: string;
  userId: string;
  timestamp: string;
  role: string;
  department: Department;
  loginFrequency: number;       // logins / day
  fileAccessCount: number;      // files / day
  sensitiveFilesAccessed: number;
  emailActivity: number;        // emails sent / day
  externalRecipients: number;   // external emails / day
  usbUsage: boolean;            // USB storage connected
  afterHoursActivity: boolean;  // activity outside 8am-6pm
  failedLogins: number;         // failed login attempts
  dataTransferMB: number;       // MB transferred
  threatScore: number;          // 0.0 to 1.0 (ML probability)
  threatLabel: 'Normal' | 'Threat';
  riskLevel: RiskLevel;
  threatCategory: ThreatCategory;
  investigationStatus?: 'Unreviewed' | 'Investigating' | 'Resolved' | 'False Positive';
}

export interface PredictionResult {
  userId: string;
  isThreat: boolean;
  riskProbability: number; // 0 to 100
  riskLevel: RiskLevel;
  modelName: string;
  featureSelectionMethod: string;
  confidence: number;
  contributingFeatures: {
    name: string;
    importance: number;
    value: string | number;
    impact: 'critical' | 'elevated' | 'normal';
    description: string;
  }[];
  recommendedAction: string;
  timestamp: string;
}

export interface SecurityAlert {
  id: string;
  userId: string;
  title: string;
  description: string;
  riskLevel: RiskLevel;
  riskProbability: number;
  threatCategory: ThreatCategory;
  timestamp: string;
  status: 'Active' | 'Investigating' | 'Resolved';
  keyAnomalies: string[];
}

export interface ModelMetrics {
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  rocAuc: number;
  confusionMatrix: {
    truePositive: number;
    falsePositive: number;
    trueNegative: number;
    falseNegative: number;
  };
}

export interface FeatureWeight {
  feature: string;
  fullName: string;
  coefficient: number;
  absoluteValue: number;
  status: 'selected' | 'removed';
  importanceRF: number; // Random Forest feature importance
  domainRelevance: string;
}

export interface PredictionHistoryEntry {
  id: string;
  date: string;
  time: string;
  userId: string;
  prediction: 'Threat' | 'Normal';
  probability: number;
  riskLevel: RiskLevel;
  model: string;
  status: 'Active' | 'Resolved' | 'Investigating';
  activitySnapshot: {
    logins: number;
    files: number;
    emails: number;
    usb: boolean;
    afterHours: boolean;
  };
}
